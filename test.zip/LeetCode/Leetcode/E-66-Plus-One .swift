/*
 Given a non-empty array of decimal digits representing a non-negative integer, increment one to the integer.
 
 The digits are stored such that the most significant digit is at the head of the list, and each element in the array contains a single digit.
 
 You may assume the integer does not contain any leading zero, except the number 0 itself.
 
 Example 1:
 
 Input: digits = [1,2,3]
 Output: [1,2,4]
 Explanation: The array represents the integer 123.
 Example 2:
 
 Input: digits = [4,3,2,1]
 Output: [4,3,2,2]
 Explanation: The array represents the integer 4321.
 Example 3:
 
 Input: digits = [0]
 Output: [1]
 
 7 = [7] , 7 + 1 = 8 = [8]
 
 19 = [1,9] , 19 + 1 = 20 = [2,0]。
 
 999 = [9,9,9] , 999 + 1 = 1000 = [1,0,0,0]
 
 
 */



private func plusOne_Solution1(_ digits: [Int]) -> [Int] {
    
    var digits = digits
    for i in stride(from: digits.count-1, to: -1, by: -1){
        
        digits[i] += 1
        
        if digits[i] > 9 {
            digits[i] = 0
            if i - 1 == -1{
                digits.insert(1, at: 0)
                break
            }
        }else{
            break
        }
        
    }
    
    return digits
}





private func plusOne_Solution2(_ digits: [Int]) -> [Int] {
    var digits = digits
    
    digits[digits.count-1] += 1
    
    while digits.contains(10) {
        
        let index = digits.lastIndex(of:10)!
        digits[index] = 0
        
        if index - 1 >= 0 {
            digits[index-1] += 1
        }else{
            digits.insert(1, at: 0)
        }
        
    }
    
    return digits
}



