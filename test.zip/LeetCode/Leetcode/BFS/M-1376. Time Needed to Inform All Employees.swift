//
//  M-1376. Time Needed to Inform All Employees.swift
//  Leetcode
//
//  Created by Lucas on 5/29/22.
//

private func numOfMinutes(_ n: Int, _ headID: Int, _ manager: [Int], _ informTime: [Int]) -> Int {
    var time = Array<Int>(repeating: 0, count: n)
    var managerToEmployeeMap = [Int:[Int]]()
    for (i,m) in manager.enumerated(){
        managerToEmployeeMap[m, default: [Int]()].append(i)
    }
    var stack = [headID]
    
    while !stack.isEmpty{
        let count = stack.count
        for _ in 0..<count{
            let m = stack.removeLast()
            for employee in managerToEmployeeMap[m, default: [Int]()]{
                time[employee] = time[m] + informTime[m]
                stack.append(employee)
            }
        }
    }
    
    return time.max()!
}
