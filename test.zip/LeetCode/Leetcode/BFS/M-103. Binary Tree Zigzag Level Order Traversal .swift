   /*
    Given a binary tree, return the zigzag level order traversal of its nodes’ values. (ie, from left to right, then right to left for the next level and alternate between).

    For example:
    Given binary tree [3,9,20,null,null,15,7],

        3
       / \
      9  20
        /  \
       15   7
    return its zigzag level order traversal as:

    [
      [3],
      [20,9],
      [15,7]
    ]
    */
   
   
private func zigzagLevelOrder(_ root: TreeNode?) -> [[Int]] {
        guard  let root = root else {
            return []
        }
        
        var queue = [TreeNode]()
        var result = [[Int]]()
        queue.append(root)
        var index = 0
        
        while !queue.isEmpty {
            
            var levelCount = queue.count
            var levelArr:[Int] = []
            while levelCount > 0 {
                levelCount -= 1

                let tree = queue.removeFirst()
                if index % 2 != 0 {
                    levelArr.insert(tree.val, at:0)
                }else{
                    levelArr.append(tree.val)
                }

                if let left = tree.left {
                    queue.append(left)
                }
                if let right = tree.right {
                    queue.append(right)
                }
           
                
                
            }
            
            result.append(levelArr)
            index += 1
            
        }
        
        return result
    }
    
