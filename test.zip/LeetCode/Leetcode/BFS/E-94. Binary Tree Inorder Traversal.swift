/*
 Given the root of a binary tree, return the inorder traversal of its nodes' values.

  

 Example 1:


 Input: root = [1,null,2,3]
 Output: [1,3,2]
 Example 2:

 Input: root = []
 Output: []
 Example 3:

 Input: root = [1]
 Output: [1]
 
 */


/*
                                Optional(1)
                            _________/ \_________
                Optional(2)                     Optional(3)
                /          \                      /        \
        Optional(4)     Optional(5)       Optional(6)      nil
            /    \          /    \               /            \
        nil      nil     nil     nil      Optional(7)      Optional(8)
 4
 2
 5
 1
 7
 6
 8
 3
 
 */



private func inOrderTraversal(_ root: TreeNode?) -> [Int] {
    var result = [Int]()
    inOrderHelper(root,&result)
    return result
}

private func inOrderHelper(_ node: TreeNode?,_ result:inout [Int]) {
    guard let node = node else { return }
    
    inOrderHelper(node.left, &result)
    inOrderHelper(node.right,&result)
    result.append(node.val)
}


