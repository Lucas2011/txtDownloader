/*
 Given the root of a binary tree, return an array of the largest value in each row of the tree (0-indexed).

  

  

 Example 1:


 Input: root = [1,3,2,5,3,null,9]
 Output: [1,3,9]
 Example 2:

 Input: root = [1,2,3]
 Output: [1,3]
 Example 3:

 Input: root = [1]
 Output: [1]
 Example 4:

 Input: root = [1,null,2]
 Output: [1,2]
 Example 5:

 Input: root = []
 Output: []

 */

private func largestValues(_ root: TreeNode?) -> [Int] {
    
    
    guard let root = root else {return []}
    
    var queue = [TreeNode]()
    var result = [Int]()
    queue.append(root)
    
    
    
    while !queue.isEmpty {
        
        let size = queue.count
        var levelArray = [Int]()
        var largest = Int.min
        for _ in 0 ..< size {
            let tree = queue.first
            queue.removeFirst()
            largest = tree!.val > largest ? tree!.val : largest
            
            levelArray.append(tree!.val)
            if let left = tree?.left {
                queue.append(left)
            }
            if let right = tree?.right {
                queue.append(right)
                
            }
            
            
            
        }
        
        result.append(largest)
        
    }
    
    
    return result
    
}
