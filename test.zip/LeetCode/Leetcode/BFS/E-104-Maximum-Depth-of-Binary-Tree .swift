/*
 Given the root of a binary tree, return its maximum depth.
 
 A binary tree's maximum depth is the number of nodes along the longest path from the root node down to the farthest leaf node.
 
 
 
 Example 1:
 
 
 Input: root = [3,9,20,null,null,15,7]
 Output: 3
 Example 2:
 
 Input: root = [1,null,2]
 Output: 2
 Example 3:
 
 Input: root = []
 Output: 0
 Example 4:
 
 Input: root = [0]
 Output: 1
 
 */
/**
 * Definition for a binary tree node.
 * public class TreeNode {
 *     public var val: Int
 *     public var left: TreeNode?
 *     public var right: TreeNode?
 *     public init() { self.val = 0; self.left = nil; self.right = nil; }
 *     public init(_ val: Int) { self.val = val; self.left = nil; self.right = nil; }
 *     public init(_ val: Int, _ left: TreeNode?, _ right: TreeNode?) {
 *         self.val = val
 *         self.left = left
 *         self.right = right
 *     }
 * }
 */

private func maxDepth(_ root: TreeNode?) -> Int {
    if root == nil { return 0 }
    return 1 + max(maxDepth(root!.left), maxDepth(root!.right))
    
}

//BFS
func maxDepth1(_ root: TreeNode?) -> Int {
    
    guard let root = root else { return 0}
    var queue = [TreeNode]()
    var output = 0
    queue.append(root)
    
    while queue.isEmpty == false {
        // start new level
        // number of elements in the current level
        var levelCount = queue.count
        while levelCount > 0 {
            let node = queue.first!
            queue.removeFirst()
            levelCount -= 1
            // Add Left child node
            if let left = node.left{
                queue.append(left)
            }
            // Add right child node
            if let right = node.right{
                queue.append(right)
            }
        }
        // Add nodes by level
        output = output + 1
    }
    return output
}




