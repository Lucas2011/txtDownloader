//
//  E-101. Symmetric Tree .swift
//  leetcode
//
//  Created by Lucas on 10/28/21.
//  Copyright © 2021 Lucas. All rights reserved.
//

/*
 Given a binary tree, check whether it is a mirror of itself (ie, symmetric around its center).

 For example, this binary tree [1,2,2,3,4,4,3] is symmetric:

     1
    / \
   2   2
  / \ / \
 3  4 4  3
  

 But the following [1,2,2,null,3,null,3] is not:

     1
    / \
   2   2
    \   \
    3    3
  

 Follow up: Solve it both recursively and iteratively.


 */
/**
 * Definition for a binary tree node.
 * public class TreeNode {
 *     public var val: Int
 *     public var left: TreeNode?
 *     public var right: TreeNode?
 *     public init() { self.val = 0; self.left = nil; self.right = nil; }
 *     public init(_ val: Int) { self.val = val; self.left = nil; self.right = nil; }
 *     public init(_ val: Int, _ left: TreeNode?, _ right: TreeNode?) {
 *         self.val = val
 *         self.left = left
 *         self.right = right
 *     }
 * }
 */

private func isSymmetric_BFS(_ root: TreeNode?) -> Bool {
    
    guard let root = root else { return true }
    
    var queue: [TreeNode] = []
    if let left = root.left {
        queue.append(left)
    }
    if let right = root.right {
        queue.append(right)
    }
    
    while !queue.isEmpty {
        if queue.count % 2 != 0 {
            return false
        }
        let left = queue.removeFirst()
        let right = queue.removeFirst()
        
        if left.val != right.val {
            return false
        }
        if left.left?.val != right.right?.val {
            return false
        }
        if left.right?.val != right.left?.val {
            return false
        }
        
        if left.left != nil {
            queue.append(left.left!)
        }
        if right.right != nil {
            queue.append(right.right!)
        }
        if left.right != nil {
            queue.append(left.right!)
        }
        if right.left != nil {
            queue.append(right.left!)
        }
    }
    return true
}
