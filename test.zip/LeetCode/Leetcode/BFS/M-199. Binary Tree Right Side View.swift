//
//  M-199. Binary Tree Right Side View.swift
//  leetcode
//
//  Created by Lucas on 10/25/21.
//  Copyright © 2021 Lucas. All rights reserved.
//

/*
 Given the root of a binary tree, imagine yourself standing on the right side of it, return the values of the nodes you can see ordered from top to bottom.
 
 
 
 Example 1:
 
 
 Input: root = [1,2,3,null,5,null,4]
 Output: [1,3,4]
 Example 2:
 
 Input: root = [1,null,3]
 Output: [1,3]
 Example 3:
 
 Input: root = []
 Output: []
 
 */




private func rightSideView(_ root: TreeNode?) -> [Int] {
    guard let root = root else { return []}
    
    var result = [Int]()
    
    var queue = [TreeNode]()
    
    //1. Initilaize queue with ALL ENTERY POINTS
    queue.append(root)
    
    /*
     2. while queue is not empty:
     a.for each node in the queue (Currently)
     b.poll out the element(add to result)
     c.expand it, add children to the queue IN ORDER (取决于输出顺序,left, right)
     d. increase level
     */
    while !queue.isEmpty {
        
        var levelCount = queue.count
        
        result.append(queue.first!.val)
        
        while levelCount > 0 {
            levelCount -= 1
            let cur = queue.removeFirst()
            
            if let right =  cur.right{
                queue.append(right)
            }
            if let left =  cur.left{
                queue.append(left)
            }
        }
    }
    return result
    
}

