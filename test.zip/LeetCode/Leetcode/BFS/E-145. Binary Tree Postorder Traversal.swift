/*
 Given the root of a binary tree, return the postorder traversal of its nodes' values.

  

 Example 1:


 Input: root = [1,null,2,3]
 Output: [3,2,1]
 Example 2:

 Input: root = []
 Output: []
 Example 3:

 Input: root = [1]
 Output: [1]
 */


/*
                                Optional(1)
                            _________/ \_________
                Optional(2)                     Optional(3)
                /          \                      /        \
        Optional(4)     Optional(5)       Optional(6)      nil
            /    \          /    \               /            \
        nil      nil     nil     nil      Optional(7)      Optional(8)
4
5
2
7
8
6
3
1
 
 */
private func postorderTraversal(_ root: TreeNode?) -> [Int] {
    var result = [Int]()
    postOrderHelper(root,&result)
    return result
}

private func postOrderHelper(_ node: TreeNode?,_ result:inout [Int]) {
    guard let node = node else { return }
    
    postOrderHelper(node.left, &result)
    postOrderHelper(node.right,&result)
    result.append(node.val)
}

