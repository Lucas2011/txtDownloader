//
//  M-102. Binary Tree Level Order Traversal .swift
//  leetcode
//
//  Created by Lucas on 10/25/21.
//  Copyright © 2021 Lucas. All rights reserved.
//

/*
 Given the root of a binary tree, return the level order traversal of its nodes' values. (i.e., from left to right, level by level).
 
 Example 1:
 
 Input: root = [3,9,20,null,null,15,7]
 Output: [[3],[9,20],[15,7]]
 Example 2:
 
 Input: root = [1]
 Output: [[1]]
 Example 3:
 
 Input: root = []
 Output: []
 
 */


/*
 1. Initilaize queue with ALL ENTERY POINTS
 2. while queue is not empty:
 a.for each node in the queue (Currently)
 b.poll out the element(add to result)
 c.expand it, add children to the queue IN ORDER (取决于输出顺序,left, right)
 d. increase level
 */

private func levelOrder(_ root: TreeNode?) -> [[Int]] {
    
    guard let root = root else {return []}
    
    var queue = [TreeNode]()
    queue.append(root)// 1. Initilaize queue with ALL ENTERY POINTS
    
    var result = [[Int]]()
    
    while !queue.isEmpty {
        var levelArr = [Int]()
        let size = queue.count
        
        for _ in 0 ..< size { // a.for each node in the queue (Currently)
            let currentLevelTree = queue.first // b.poll out the element(add to result)
            levelArr.append(currentLevelTree!.val)
            queue.removeFirst()
            if let left = currentLevelTree?.left { //c.expand it, add children to the queue IN ORDER (取决于输出顺序,left, right)
                queue.append(left)
            }
            if let right = currentLevelTree?.right {
                queue.append(right)
            }
        }
        result.append(levelArr) // d. increase level
    }
    
    return result
}

