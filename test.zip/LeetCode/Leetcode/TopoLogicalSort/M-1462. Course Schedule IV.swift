/*
 There are a total of numCourses courses you have to take, labeled from 0 to numCourses - 1. You are given an array prerequisites where prerequisites[i] = [ai, bi] indicates that you must take course ai first if you want to take course bi.
 
 For example, the pair [0, 1] indicates that you have to take course 0 before you can take course 1.
 Prerequisites can also be indirect. If course a is a prerequisite of course b, and course b is a prerequisite of course c, then course a is a prerequisite of course c.
 
 You are also given an array queries where queries[j] = [uj, vj]. For the jth query, you should answer whether course uj is a prerequisite of course vj or not.
 
 Return a boolean array answer, where answer[j] is the answer to the jth query.
 
 
 
 Example 1:
 
 
 Input: numCourses = 2, prerequisites = [[1,0]], queries = [[0,1],[1,0]]
 Output: [false,true]
 Explanation: The pair [1, 0] indicates that you have to take course 1 before you can take course 0.
 Course 0 is not a prerequisite of course 1, but the opposite is true.
 Example 2:
 
 Input: numCourses = 2, prerequisites = [], queries = [[1,0],[0,1]]
 Output: [false,false]
 Explanation: There are no prerequisites, and each course is independent.
 */


private func checkIfPrerequisite(_ numCourses: Int, _ prerequisites: [[Int]], _ queries: [[Int]]) -> [Bool] {
    
    var graph = Array(repeating: [Int](), count: numCourses)

    for course in prerequisites{
        graph[course[0]].append(course[1])
    }
    var res = [Bool]()
    
    for query in queries{
        let pre = query[0]
        let cur = query[1]
        let isReachable = bfs(graph: graph, from: pre, to: cur)
        res.append(isReachable)
    }
    
    
    return res
}

private func bfs(graph:[[Int]], from: Int, to: Int) ->Bool{
    var marked = Set<Int>()
    
    func dfs(from: Int, to: Int) -> Bool {
        // The vertex is reachable
        if to == from {
            return true
        }
        
        // Cycle found
        if marked.contains(from) {
            return false
        }
        
        marked.insert(from)
        
        for u in graph[from] {
            if !marked.contains(u), dfs(from: u, to: to) {
                return true
            }
        }
        return false
    }
    
    return dfs(from: from, to: to)
}
