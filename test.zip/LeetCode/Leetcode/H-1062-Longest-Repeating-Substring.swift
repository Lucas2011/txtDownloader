/*
 Given a string S, find out the length of the longest repeating substring(s). Return 0 if no repeating substring exists.

  

 Example 1:

 Input: “abcd”
 Output: 0
 Explanation: There is no repeating substring.
 Example 2:

 Input: “abbaba”
 Output: 2
 Explanation: The longest repeating substrings are “ab” and “ba”, each of which occurs twice.
 Example 3:

 Input: “aabcaabdaab”
 Output: 3
 Explanation: The longest repeating substring is “aab”, which occurs 3 times.
 Example 4:

 Input: “aaaaa”
 Output: 4
 Explanation: The longest repeating substring is “aaaa”, which occurs twice.
  

 Constraints:

 The string S consists of only lowercase English letters from ‘a’ - ‘z’.
 1 <= S.length <= 1500

 */


private func longestRepeatingSubstring(_ str:String) -> Int {
        
        var l = 0 , r = str.count - 1 , mid = 0
        
        while l < r {
            mid = l + (r - l + 1)/2
            if ifContins(str, length: mid){
                l = mid
            }else{
                r = mid - 1
            }
        }
        
        return l
    }
    
private func ifContins(_ s:String, length:Int) -> Bool {
        var dict = [String:String]()
        var j = 0, subString = ""
        for i in 0 ... s.count - length{
            j = i + length - 1
            let startIndex = s.index(s.startIndex, offsetBy: i)
            let endIndex = s.index(s.startIndex, offsetBy: j)
            subString = String(s[startIndex...endIndex])
            print("\(s), i == \(i),j == \(j),\(subString)")
            if dict[subString] != nil{
                print("\(subString) == True length = \(length)")

                return true
            }else{
                dict[subString] = subString
            }
        }
        return false
    }
    
    

