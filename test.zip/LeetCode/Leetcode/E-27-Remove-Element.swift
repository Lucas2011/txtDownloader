/*
 * Difficulty:
 * Easy
 *
 * Desc:
 * Given a sorted array, remove the duplicates in place such that each element appear only once and return the new length.
 * Do not allocate extra space for another array, you must do this in place with constant memory.
 *
 Example 1:
 
 Input: nums = [3,2,2,3], val = 3
 Output: 2, nums = [2,2]
 Explanation: Your function should return length = 2, with the first two elements of nums being 2.
 It doesn't matter what you leave beyond the returned length. For example if you return 2 with nums = [2,2,3,3] or nums = [2,2,0,0], your answer will be accepted.
 Example 2:
 
 Input: nums = [0,1,2,2,3,0,4,2], val = 2
 Output: 5, nums = [0,1,4,0,3]
 Explanation: Your function should return length = 5, with the first five elements of nums containing 0, 1, 3, 0, and 4. Note
 that the order of those five elements can be arbitrary. It doesn't matter what values are set beyond the returned length.
 
 * 去除一个已排序的数组中重复的元素，且不能占用额外的空间（不能新建）
 */

private func removeElement_Solution1(_ nums: inout [Int], _ val: Int) -> Int {
    nums = nums.filter{$0 != val}
    
    return nums.count
}




private func removeElement_Solution2(_ nums: inout [Int], _ val: Int) -> Int {
    
    var i = 0;
    for j in 0..<nums.count{
        if (nums[j] != val) {
            nums[i] = nums[j];
            i+=1;
        }
    }
    return i;
}



