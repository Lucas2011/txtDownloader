/*
 Given an array of strings words (without duplicates), return all the concatenated words in the given list of words.
 
 A concatenated word is defined as a string that is comprised entirely of at least two shorter words in the given array.
 
 
 
 Example 1:
 
 Input: words = ["cat","cats","catsdogcats","dog","dogcatsdog","hippopotamuses","rat","ratcatdogcat"]
 Output: ["catsdogcats","dogcatsdog","ratcatdogcat"]
 Explanation: "catsdogcats" can be concatenated by "cats", "dog" and "cats";
 "dogcatsdog" can be concatenated by "dog", "cats" and "dog";
 "ratcatdogcat" can be concatenated by "rat", "cat", "dog" and "cat".
 Example 2:
 
 Input: words = ["cat","dog","catdog"]
 Output: ["catdog"]
 */
func findAllConcatenatedWordsInADict(_ words: [String]) -> [String] {
    var res:[String] = [String]()
    let dict:Set<String> = Set(words)
    for vocabulary in words
    {
        let n  = vocabulary.count
        if n == 0 {continue}
        var dp:[Bool] = [Bool](repeating:false,count:n + 1)
        dp[0] = true
        for i in 0..<n
        {
            if !dp[i] {continue}
            for j in (i + 1)...n
            {
                let str = vocabulary.subString(i, j - i)
                if j - i < n && dict.contains(str)
                {
                    dp[j] = true
                }
            }
            if dp[n]
            {
                res.append(vocabulary)
                break
            }
        }
    }
    return res

}

extension String {
    // 截取字符串：指定索引和字符数
    // - begin: 开始截取处索引
    // - count: 截取的字符数量
    func subString(_ begin:Int,_ count:Int) -> String {
        let start = self.index(self.startIndex, offsetBy: max(0, begin))
        let end = self.index(self.startIndex, offsetBy:  min(self.count, begin + count))
        return String(self[start..<end])
    }
}
