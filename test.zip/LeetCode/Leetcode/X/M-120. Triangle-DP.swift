/*
 Given a triangle array, return the minimum path sum from top to bottom.

 For each step, you may move to an adjacent number of the row below. More formally, if you are on index i on the current row, you may move to either index i or index i + 1 on the next row.

  

 Example 1:

 Input: triangle = [[2],[3,4],[6,5,7],[4,1,8,3]]
 Output: 11
 Explanation: The triangle looks like:
    2
   3 4
  6 5 7
 4 1 8 3
 The minimum path sum from top to bottom is 2 + 3 + 5 + 1 = 11 (underlined above).
 Example 2:

 Input: triangle = [[-10]]
 Output: -10
 */








private func minimumTotal(_ triangle: [[Int]]) -> Int {
       let n  = triangle.count
       if n == 0 {return -1}
       var dp = [[Int]](repeating: [Int](repeating: 0, count: n), count: n)
       dp[0][0] = triangle[0][0]
       

       for i in 1 ..< n{
           //1.初始化本行最左边的点和最右边的点
           dp[i][0] = dp[i-1][0] + triangle[i][0]//dp[i-1][0] 最右边的头上的节点 + triangle[i][0] 自身节点
           dp[i][i] = dp[i-1][i-1] + triangle[i][i]//dp[i-1][i] 最左边的头上的节点 + triangle[i][i] 自身节点

           for j in 1 ..< i {
               //2. 方程 function 状态转移, 当前路径的最小路径
               dp[i][j] = min(dp[i-1][j-1], dp[i-1][j]) + triangle[i][j]
           }
       }
       
       //3. 答案 answer 三角形底层任意一个节点都有可能是最小路径的重点
       //返回最小的值
       
       let ans = dp.last!.sorted().first!
       return ans
   }
