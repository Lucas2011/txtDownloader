//
//  M-310. Minimum Height Trees .swift
//  Leetcode
//
//  Created by Lucas on 3/17/22.
//
/*
 拓扑排序 Topological Sorting
 1.选择一个入度为0 的定点
 2.从 AOV 网中删除此顶点 及次定点为起点的关联变
 3.重复上面两部直到不存在入度为0 的定点为止
 4.若 aov 网中还有定点,则说明有向图存在回路
 
 
 */
private func findMinHeightTrees(_ n: Int, _ edges: [[Int]]) -> [Int] {
    guard !edges.isEmpty else { return [0] }
    
    var vertices = Array(repeating:Set<Int>(), count:n) // 顶点：相邻顶点们
    for e in edges {
        vertices[e[0]].insert(e[1])
        vertices[e[1]].insert(e[0])
        
    }
    
    var leafs = vertices.enumerated().filter { $0.1.count == 1 }.map { $0.0 }
    
    var n = n
    while n > 2 {
        var newLeafs = [Int]()
        for leaf in leafs {
            let parent = vertices[leaf].first!
            vertices[parent].remove(leaf)
            if vertices[parent].count == 1 {
                newLeafs.append(parent)
            }
        }
        n -= leafs.count
        leafs = newLeafs
    }
    return leafs
}

