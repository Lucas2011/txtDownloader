/*
 687. Longest Univalue Path
 Medium
 
 3028
 
 608
 
 Add to List
 
 Share
 Given the root of a binary tree, return the length of the longest path, where each node in the path has the same value. This path may or may not pass through the root.
 
 The length of the path between two nodes is represented by the number of edges between them.
 
 
 
 Example 1:
 
 
 Input: root = [5,4,5,1,1,5]
 Output: 2
 Example 2:
 
 
 Input: root = [1,4,5,4,4,5]
 Output: 2
 */



private var ans = 0
private func univaluePath(_ root: TreeNode?) -> Int {
    if root == nil {return 0}
    
    var l = 0, r = 0
    
    if let left = root?.left {
        l = univaluePath(left) // + all left node to root
    }
    if let right = root?.right {
        r = univaluePath(right) // + all right node to root
    }
    var pl = 0,pr = 0
    if (root?.left != nil && root?.val == root?.left?.val){
        pl = l + 1
    }
    if (root?.right != nil && root?.val == root?.right?.val){
        pr = r + 1
    }
    
    
    ans = max(ans, pl + pr)
    return max(pl, pr)
}

private func longestUnivaluePath(_ root: TreeNode?) -> Int {
    _ = univaluePath(root)
    return ans
}
