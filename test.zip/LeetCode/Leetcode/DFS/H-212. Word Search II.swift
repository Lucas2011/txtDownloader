/*
 212. Word Search II
 Hard

 5799

 214

 Add to List

 Share
 Given an m x n board of characters and a list of strings words, return all words on the board.

 Each word must be constructed from letters of sequentially adjacent cells, where adjacent cells are horizontally or vertically neighboring. The same letter cell may not be used more than once in a word.

  

 Example 1:


 Input: board = [["o","a","a","n"],["e","t","a","e"],["i","h","k","r"],["i","f","l","v"]], words = ["oath","pea","eat","rain"]
 Output: ["eat","oath"]
 Example 2:


 Input: board = [["a","b"],["c","d"]], words = ["abcb"]
 Output: []
 */


/*
 Trie:
 root:Trie()
 children:[char:Trie]
 isEnd:Bool (is a word)
 value:String
 
 */



/*
 搜索 208  的 TrieTree
 */

private class TrieNode {
    var isEnd:Bool
    var children: [Character: TrieNode]
    var word:String!
    init() {
        self.isEnd = false
        self.children = [Character : TrieNode]()
        self.word = nil
    }
}

private class TrieTree {
    let root = TrieNode()
    /** Initialize your data structure here. */
    init() {
        
    }
    /** Inserts a word into the trie. */
    func insert(_ word: String) {
        var currentNode = root
        for c in word {
            if let nextNode = currentNode.children[c] {
                currentNode = nextNode
            } else {
                let nextNode = TrieNode()
                currentNode.children[c] = nextNode
                currentNode = nextNode
            }
        }
        currentNode.isEnd = true
        currentNode.word = word
    }
    /** Returns if the word is in the trie. */
    func search(_ word: String) -> Bool {
        var currentNode = root
        for c in word {
            if let node = currentNode.children[c] {
                currentNode = node
            } else {
                return false
            }
        }
        return currentNode.isEnd
    }
    
    /** Returns if there is any word in the trie that starts with the given prefix. */
    func startsWith(_ prefix: String) -> Bool {
        var currentNode = root
        for c in prefix {
            if let node = currentNode.children[c] {
                currentNode = node
            } else {
                return false
            }
        }
        return true
    }
}
/* ------------------------------- */
private func findWords(_ board: [[Character]], _ words: [String]) -> [String] {
    
    let m = board.count, n = board[0].count
    let trie = TrieTree()//搜索 208  的 TrieTree 
    var record = [[Bool]](repeating:[Bool](repeating:false, count:n), count:m)
    var result = Set<String>()
    
    
    for word in words {
        trie.insert(word)
    }
    
    for x in 0 ..< m {
        for y in 0 ..< n {
            guard let node = child(board,trie.root,x,y) else { //get letter
                continue
            }
            search(board,&record,node,x,y, &result)
        }
    }
    return Array(result)
    
}

private func child(_ board: [[Character]],_ node:TrieNode,_ x:Int,_ y:Int) -> TrieNode? {
    guard x < board.count, x >= 0, y < board[0].count, y >= 0 else {return nil}
    return node.children[board[x][y]]
}

private func search (_ board: [[Character]],_ record:inout [[Bool]], _ node:TrieNode,_ x:Int, _ y:Int, _ result:inout Set<String>) {
    guard x < board.count, x >= 0, y < board[0].count, y >= 0, !record[x][y] else {return}
    if let word = node.word {
        result.insert(word)
    }
    record[x][y] = true
    if let nextNode = child(board,node,x+1,y) {
        search(board,&record,nextNode,x+1,y, &result)
    }
    if let nextNode = child(board,node,x-1,y) {
        search(board,&record,nextNode,x-1,y, &result)
    }
    if let nextNode = child(board,node,x,y+1) {
        search(board,&record,nextNode,x,y+1, &result)
    }
    if let nextNode = child(board,node,x,y-1) {
        search(board,&record,nextNode,x,y-1, &result)
    }
    record[x][y] = false
}
