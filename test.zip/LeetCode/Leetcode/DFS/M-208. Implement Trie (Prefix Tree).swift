/*
 
 */


private class TrieNode {
    var isEnd:Bool
    var children: [Character: TrieNode]
    var word:String!
    init() {
        self.isEnd = false
        self.children = [Character : TrieNode]()
        self.word = nil
    }
    
    
}

private class TrieTree {
    let root = TrieNode()
    /** Initialize your data structure here. */
    init() {
        
    }
    
    /** Inserts a word into the trie. */
    func insert(_ word: String) {
        var currentNode = root
        for c in word {
            if let nextNode = currentNode.children[c] {
                currentNode = nextNode
            } else {
                let nextNode = TrieNode()
                currentNode.children[c] = nextNode
                currentNode = nextNode
            }
        }
        currentNode.isEnd = true
        currentNode.word = word
    }
    
    /** Returns if the word is in the trie. */
    func search(_ word: String) -> Bool {
        var currentNode = root
        for c in word {
            if let node = currentNode.children[c] {
                currentNode = node
            } else {
                return false
            }
        }
        return currentNode.isEnd
    }
    
    /** Returns if there is any word in the trie that starts with the given prefix. */
    func startsWith(_ prefix: String) -> Bool {
        var currentNode = root
        for c in prefix {
            if let node = currentNode.children[c] {
                currentNode = node
            } else {
                return false
            }
        }
        return true
    }
}
