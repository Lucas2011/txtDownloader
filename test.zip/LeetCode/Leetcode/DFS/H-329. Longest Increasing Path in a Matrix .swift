/*
 329. Longest Increasing Path in a Matrix
 Hard
 
 5155
 
 88
 
 Add to List
 
 Share
 Given an m x n integers matrix, return the length of the longest increasing path in matrix.
 
 From each cell, you can either move in four directions: left, right, up, or down. You may not move diagonally or move outside the boundary (i.e., wrap-around is not allowed).
 
 
 
 Example 1:
 
 
 Input: matrix = [[9,9,4],[6,6,8],[2,1,1]]
 Output: 4
 Explanation: The longest increasing path is [1, 2, 6, 9].
 Example 2:
 
 
 Input: matrix = [[3,4,5],[3,2,6],[2,2,1]]
 Output: 4
 Explanation: The longest increasing path is [3, 4, 5, 6]. Moving diagonally is not allowed.
 */



private func longestIncreasingPath(_ matrix: [[Int]]) -> Int {
    if matrix.count == 0 {return 0}
    let m = matrix.count, n = matrix[0].count,direction = [0,1,0,-1,0]
    
    var dp = Array(repeating: Array(repeating: -1, count: n), count: m)
    var answer = 0
    
    for i in 0 ..< m
    {
        for j in 0 ..< n
        {
            
            answer = max(answer, dfs(matrix: matrix, i: i, j: j, dp: &dp, direction: direction))
            
        }
    }
    
    
    
    
    return answer
}

private func dfs(matrix: [[Int]], i:Int, j:Int,dp: inout[[Int]], direction:[Int]) -> Int{
    if dp[i][j] != -1 {return dp[i][j]}
    
    dp[i][j] = 1
    
    for k in 0 ..< 4 {
        let tx = direction[k] + i ,ty = direction[k+1] + j
        if  tx >= matrix.count || tx < 0 || ty >= matrix[0].count || ty < 0 || matrix[tx][ty] <= matrix[i][j] {continue}
        dp[i][j] = max(dp[i][j], 1 + dfs(matrix: matrix, i: tx, j: ty, dp: &dp, direction: direction))
        
    }
    
    
    return dp[i][j]
}


private func longestIncreasingPath_2(_ matrix: [[Int]]) -> Int {
    
    var result = [[Int]]()
    var temp = [Int]()
    var answer = 0
    
    func dfs(matrix: [[Int]], i:Int, j:Int,dp: inout[[Bool]], direction:[Int]){
        temp.append(matrix[i][j])
        if temp.count > answer {
            answer = temp.count
            result.append(temp)
        }
        dp[i][j] = true
        
        for k in 0 ..< 4 {
            let tx = direction[k] + i ,ty = direction[k+1] + j
            
            if  tx >= matrix.count || tx < 0 || ty >= matrix[0].count || ty < 0 || dp[tx][ty] == true {continue}
            if matrix[tx][ty] <= matrix[i][j] {
                continue
            }
            dfs(matrix: matrix, i: tx, j: ty, dp: &dp, direction: direction)
        }
        temp.removeLast()
        
        dp[i][j] = false
    }
    
    if matrix.count == 0 {return 0}
    let m = matrix.count, n = matrix[0].count,direction = [0,1,0,-1,0]
    
    var dp = Array(repeating: Array(repeating: false, count: n), count: m)
    
    for i in 0 ..< m
    {
        for j in 0 ..< n
        {
            
            dfs(matrix: matrix, i: i, j: j, dp: &dp, direction: direction)
            
        }
    }
    
    let array = result.sorted(by: {$0.count < $1.count})
    
    return array.last!.count
}
