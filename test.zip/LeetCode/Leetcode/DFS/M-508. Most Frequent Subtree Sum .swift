/*
 Given the root of a binary tree, return the most frequent subtree sum. If there is a tie, return all the values with the highest frequency in any order.
 
 The subtree sum of a node is defined as the sum of all the node values formed by the subtree rooted at that node (including the node itself).
 
 
 
 Example 1:
 
 
 Input: root = [5,2,-3]
 Output: [2,-3,4]
 Example 2:
 
 
 Input: root = [5,2,-5]
 Output: [2]

 */

/*
 
 返回出现次数最多的 sum of each root
 */

private func findFrequentTreeSum(_ root: TreeNode?) -> [Int] {
    
    guard let root = root else {return []}
    var maxCount = 0
    var map = [Int:Int]()
    var answer = [Int]()
    _ = DFS(root, map: &map,maxCount: &maxCount)
    
    for (key,value) in map{
        if value == maxCount {
            answer.append(key)
        }
    }
    
    
    
    return answer
}
private func DFS(_ root: TreeNode?, map: inout [Int:Int],maxCount:inout Int) -> Int {
    guard let root = root else {return 0}
    
    let left = DFS(root.left, map: &map,maxCount: &maxCount)
    let right = DFS(root.right, map: &map,maxCount: &maxCount)
    let sum = left + right + root.val
    let currentCount = map[sum] ?? 0
    map[sum] =  currentCount + 1
    maxCount = max(maxCount,currentCount + 1)
    return sum
}

