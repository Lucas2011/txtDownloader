/*
 17. Letter Combinations of a Phone Number
 Medium
 
 18704
 
 1009
 
 Add to List
 
 Share
 Given a string containing digits from 2-9 inclusive, return all possible letter combinations that the number could represent. Return the answer in any order.
 
 A mapping of digits to letters (just like on the telephone buttons) is given below. Note that 1 does not map to any letters.
 
 
 
 
 Example 1:
 
 Input: digits = "23"
 Output: ["ad","ae","af","bd","be","bf","cd","ce","cf"]
 Example 2:
 
 Input: digits = ""
 Output: []
 Example 3:
 
 Input: digits = "2"
 Output: ["a","b","c"]
 
 
 Constraints:
 
 0 <= digits.length <= 4
 digits[i] is a digit in the range ['2', '9'].
 */
private func letterCombinations(_ digits: String) -> [String] {
    guard !digits.isEmpty else { return [] }
    
    let keyBoard = [
        "0": "",
        "1": "",
        "2": "abc",
        "3": "def",
        "4": "ghi",
        "5": "jkl",
        "6": "mno",
        "7": "pqrs",
        "8": "tuv",
        "9": "wxyz"
    ]
    
    
    var stringBuild = [String]()
    var result = [String]()
    
    dfs(digits: digits, index: 0, stringBuilder: &stringBuild, result: &result,keyboard:keyBoard)
    
    return result
}


private func dfs (digits:String, index:Int, stringBuilder:inout [String], result:inout [String], keyboard:[String:String]) {
    
    if index == digits.count {
        result.append(stringBuilder.joined())
        return
    }
    
    let digit = String(digits[digits.index(digits.startIndex, offsetBy: index)])
    let letters = keyboard[digit]!
    
    print("result: \(result)")
    
    for char in letters {
        stringBuilder.append(String(char))
        print("stringBuilder: \(stringBuilder)")
        dfs(digits: digits, index: index + 1, stringBuilder: &stringBuilder, result: &result, keyboard:keyboard)
        stringBuilder.removeLast()  // Corrected to ensure we're modifying the right array
    }
    
}

