/*
 Given the root of a binary tree, return its maximum depth.
 
 A binary tree's maximum depth is the number of nodes along the longest path from the root node down to the farthest leaf node.
 
 
 
 Example 1:
 
 
 Input: root = [3,9,20,null,null,15,7]
 Output: 3
 Example 2:
 
 Input: root = [1,null,2]
 Output: 2
 Example 3:
 
 Input: root = []
 Output: 0
 Example 4:
 
 Input: root = [0]
 Output: 1
 
 */

/*
 
 1 Base case,以免死循环
 2.向子问题要答案
 3. 利用子问题的答案 构建当前问题 (当前递归层的)答案
 4. 如有必要,做一些额外操作
 5. 返回答案给父问题
 */



private func maxDepth_DFS(_ root: TreeNode?) -> Int {
    
    guard let root = root else {return 0}
    
    
    let left = maxDepth_DFS(root.left)
    let right = maxDepth_DFS(root.right)
   
    
    return max(left, right) + 1
    
}


