/*
 Given a binary tree, determine if it is height-balanced.
 
 For this problem, a height-balanced binary tree is defined as:
 
 a binary tree in which the left and right subtrees of every node differ in height by no more than 1.
 
 
 
 Example 1:
 
 
 Input: root = [3,9,20,null,null,15,7]
 Output: true
 Example 2:
 
 
 Input: root = [1,2,2,3,3,null,null,4,4]
 Output: false
 Example 3:
 
 Input: root = []
 Output: true
 
 需要考虑 每个节点 是否平衡
 */
private func isBalanced(_ root: TreeNode?) -> Bool {
    guard let root = root else {
        return true
    }
    var balanced = true
    _ = level(root, balance: &balanced)
    
    return balanced
}


private func level(_ root: TreeNode?,balance:inout Bool) -> Int {
    guard let root = root else {
        return 0
    }
    
    let leftLevel = level(root.left, balance: &balance)
    let rightLevel = level(root.right, balance: &balance)
    
    if (abs(leftLevel - rightLevel) > 1){
        balance = false
        return -1
    }
    
    return max(leftLevel, rightLevel) + 1
}

//S1
private func isBalanced_S1(_ root: TreeNode?) -> Bool {
    guard let root = root else {
        return true
    }
    
    let left = level_S1(root.left)
    let right = level_S1(root.right)
    let isLeftBance = isBalanced(root.left)
    let isRightBance = isBalanced(root.right)
    
    return abs(left - right) <= 1 && isLeftBance && isRightBance
}


private func level_S1(_ root: TreeNode?) -> Int {
    guard let root = root else {
        return 0
    }
    
    let left = level_S1(root.left)
    let right = level_S1(root.right)
    
    
    return max(left, right) + 1
}
