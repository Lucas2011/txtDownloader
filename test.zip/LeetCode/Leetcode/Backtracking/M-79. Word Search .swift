
/*
 Given an m x n grid of characters board and a string word, return true if word exists in the grid.

 The word can be constructed from letters of sequentially adjacent cells, where adjacent cells are horizontally or vertically neighboring. The same letter cell may not be used more than once.

  

 Example 1:

 Input: board = [["A","B","C","E"],["S","F","C","S"],["A","D","E","E"]], word = "ABCCED"
 Output: true
 Example 2:


 Input: board = [["A","B","C","E"],["S","F","C","S"],["A","D","E","E"]], word = "SEE"
 Output: true
 Example 3:

 Input: board = [["A","B","C","E"],["S","F","C","S"],["A","D","E","E"]], word = "ABCB"
 Output: false

 */


private func exist(_ board: [[Character]], _ word: String) -> Bool {
    
    if board.count == 0 {
        return false
    }
    let m = board.count
    let n = board[0].count
    var board = board
    var wordChars = Array(word)
    for i in 0..<m {
        for j in 0..<n {
            if search(&board, i, j, &wordChars, 0) {
                return true
            }
        }
    }
    return false
    
}

private func search(_ board: inout [[Character]], _ i: Int, _ j: Int, _ wordChars: inout [Character], _ cur: Int) -> Bool {
    let m = board.count
    let n = board[0].count
    if (i < 0 || i >= m || j < 0 || j >= n || board[i][j] == "0" || board[i][j] != wordChars[cur]) {
        return false
    }
    if cur == wordChars.count - 1 {
        return true
    }
    let temp = board[i][j]
    board[i][j] = "0"
    let res = search(&board, i-1, j, &wordChars, cur+1) ||
    search(&board, i+1, j, &wordChars, cur+1) ||
    search(&board, i, j-1, &wordChars, cur+1) ||
    search(&board, i, j+1, &wordChars, cur+1)
    board[i][j] = temp
    return res
}
