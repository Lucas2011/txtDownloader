/*
 934. Shortest Bridge
 Medium
 
 2326
 
 120
 
 Add to List
 
 Share
 You are given an n x n binary matrix grid where 1 represents land and 0 represents water.
 
 An island is a 4-directionally connected group of 1's not connected to any other 1's. There are exactly two islands in grid.
 
 You may change 0's to 1's to connect the two islands to form one island.
 
 Return the smallest number of 0's you must flip to connect the two islands.
 
 
 
 Example 1:
 
 Input: grid = [[0,1],[1,0]]
 Output: 1
 Example 2:
 
 Input: grid = [[0,1,0],[0,0,0],[0,0,1]]
 Output: 2
 Example 3:
 
 Input: grid = [[1,1,1,1,1],[1,0,0,0,1],[1,0,1,0,1],[1,0,0,0,1],[1,1,1,1,1]]
 Output: 1
 */

/*
 先找出第一个 1, 然后用 dsf 遍历他 所有相连的 1,这样找到第一个岛屿
 然后用 bfs 找第二个岛屿
 
 */
private func shortestBridge(_ grid: [[Int]]) -> Int {
    let m = grid.count, n = grid[0].count
    var queue = [[Int]](), found = false, grid = grid
    
    for i in 0 ..< m{
        if found {break}
        for j in 0 ..< n{
            if found {break}
            
            if grid[i][j] == 1 {
                dsf(grid: &grid, x: i, y: j, queue: &queue)
                found = true
            }
        }
    }
    
    let direction = [0,1,0,-1,0]
    var cost = 0
    
    while !queue.isEmpty{
        var size = queue.count
        
        while (size != 0){
            size -= 1
            let cur = queue.removeFirst()
            let x = cur[0], y = cur[1]
            
            
            for i in 0 ..< 4{
                let tx = direction[i]+x, ty = direction[i+1]+y
                
                if (tx < 0 || ty < 0 || tx >= m  || ty >= n || grid[tx][ty] == 2){continue}
                
                if (grid[tx][ty] == 1) {
                    return cost
                }
                
                grid[tx][ty] = 2
                queue.append([tx,ty])
            }
        }
        
        cost += 1
    }
    
    return -1
}

private func dsf(grid: inout [[Int]], x:Int, y:Int,  queue:inout[[Int]]){
    
    if (x < 0 || y < 0 || x >= grid.count || y >= grid[0].count || grid[x][y] != 1){
        return
    }
    grid[x][y] = 2
    queue.append([x,y])
    dsf(grid: &grid, x: x-1, y: y, queue: &queue)
    dsf(grid: &grid, x: x, y: y-1, queue: &queue)
    dsf(grid: &grid, x: x+1, y: y, queue: &queue)
    dsf(grid: &grid, x: x, y: y+1, queue: &queue)
    
}
