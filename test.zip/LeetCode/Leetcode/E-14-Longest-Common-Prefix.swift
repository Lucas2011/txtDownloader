/*
 
 思路
 先找到数组最短的string,然后在判断数组元素是否包含 string 为前缀
 如果元素不包含string 且 string 不为空, string 移除最后一位
 
 
 Write a function to find the longest common prefix string amongst an array of strings.
 
 If there is no common prefix, return an empty string "".
 
 
 
 Example 1:
 
 Input: strs = ["flower","flow","flight"]
 Output: "fl"
 Example 2:
 
 Input: strs = ["dog","racecar","car"]
 Output: ""
 Explanation: There is no common prefix among the input strings.
 
 */


private func longestCommonPrefix(_ strs: [String]) -> String {
    var shortest:String!
    for values in strs {
        if shortest == nil{
            shortest = values
            continue
        }
        shortest = values.count < shortest.count ? values : shortest
    }
    
    for str in strs{
        
        while shortest.count != 0 && !str.hasPrefix(shortest) {
            shortest = String(shortest.dropLast())
        }
        
        
    }
    
    return shortest.count == 0 ? "" : shortest
    
}

