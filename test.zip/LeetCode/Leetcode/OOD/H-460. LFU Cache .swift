private class DLNode {
    var pre: DLNode?
    var next: DLNode?
    var key: Int
    var value: Int
    var count: Int
    init(_ key: Int, _ value: Int) {
        self.key = key
        self.value = value
        self.count = 1
    }
}


private class List {
    var head: DLNode?
    var tail: DLNode?
    var count: Int
    init() {
        head = DLNode(-1, -1)
        tail = DLNode(-1, -1)
        head?.next = tail
        tail?.pre = head
        count = 0
    }
    
    func moveToHead(_ node: DLNode?) {
        node?.next = head?.next
        head?.next?.pre = node
        node?.pre = head
        head?.next = node
        count += 1
    }
    
    func deleteNode(_ node: DLNode?) {
        node?.next?.pre = node?.pre
        node?.pre?.next = node?.next
        count -= 1
    }
    
}


private class LFUCache {
    var countMap: [Int: List]
    var map: [Int: DLNode?]
    var capacity: Int
    var minCount: Int
  
    init(_ capacity: Int) {
        countMap = [Int: List]()
        map = [Int: DLNode?]()
        self.capacity = capacity
        minCount = 0
    }
    
    func get(_ key: Int) -> Int {
        if capacity == 0 {
            return -1
        }
        if let node = map[key] {
            updateNode(node)
            return node!.value
        } else {
            return -1
        }
    }
    
    func put(_ key: Int, _ value: Int) {
        if capacity == 0 {
            return
        }
        if let node = map[key] {
            updateNode(node)
            node!.value = value
        } else {
            if map.count == capacity {
                let list = countMap[minCount]!
                let nodeToDelete = list.tail?.pre
                list.deleteNode(nodeToDelete)
                map[nodeToDelete!.key] = nil
            }
            minCount = 1
            let node = DLNode(key, value)
            map[key] = node
            let list = countMap[node.count, default: List()]
            list.moveToHead(node)
            countMap[node.count] = list

            
        }
    }
    func updateNode(_ node: DLNode?) {
        let list = countMap[node!.count]!
        list.deleteNode(node)
        
        if list.count == 0 && node!.count == minCount {
            minCount += 1
        }
        node!.count += 1
        let list2 = countMap[node!.count, default: List()]
        list2.moveToHead(node)
        countMap[node!.count] = list2
    }
}


