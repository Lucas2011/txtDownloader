/*
 
 */



private class DoublyLinkedList{
    var key: Int
    var value: Int
    var previous: DoublyLinkedList?
    var next: DoublyLinkedList?
    var hashValue: Int
    
    init(_ key: Int, _ value: Int) {
        self.key = key
        self.value = value
        self.hashValue = key
    }
}
private class LRUCache{
    var maxCapacity: Int
    var head: DoublyLinkedList
    var tail: DoublyLinkedList
    var dict: [Int: DoublyLinkedList]
    
    init(_ maxCapacity: Int) {
        self.maxCapacity = maxCapacity
        self.dict = [Int: DoublyLinkedList]()
        self.head = DoublyLinkedList(Int.min, Int.min)
        self.tail = DoublyLinkedList(Int.max, Int.max)
        self.head.next = self.tail
        self.tail.previous = self.head
    }
    func add(_ node: DoublyLinkedList){
        let next = head.next
        head.next = node
        node.previous = head
        node.next = next
        next?.previous = node
    }
    func remove(_ node: DoublyLinkedList){
        let previous = node.previous
        let next = node.next
        previous?.next = next
        next?.previous = previous
    }
    func get(_ key: Int) -> Int{
        if let node = dict[key]{
            remove(node)
            add(node)
            return node.value
        }
        return -1
    }
    func put(_ key: Int, _ value: Int){
        if let node = dict[key]{
            remove(node)
            dict.removeValue(forKey: key)
        }else if dict.keys.count >= maxCapacity{
            if let leastNode = tail.previous{
                remove(leastNode)
                dict.removeValue(forKey: leastNode.key)
            }
        }
        let newNode = DoublyLinkedList(key, value)
        dict[key] = newNode
        add(newNode)
    }
}







//第二解法
class Solution147_2{
    
    class LRUCache {
        var dict:Dictionary<Int, Int>
        var arr:[Int]
        var max = 0
        init(_ capacity: Int) {
            max = capacity
            arr = Array.init(repeating: -1, count: max)
            dict = Dictionary.init(minimumCapacity: max)
        }
        
        func get(_ key: Int) -> Int {
            if max == 0 {
                return -1
            }
            if dict[key] != -1 {//已存在的数据进行查找与移动
                let index = findArrIndex(value: key, arr: arr)//查找时间复杂度是o(n)
                if index != -1 {
                    moveForward(index: index, arr: &arr)//移动时间复杂度是o(n)
                }
            }
            
            return (dict[key] == nil ? -1 : dict[key])!
        }
        
        func put(_ key: Int, _ value: Int) {
            if max == 0 {
                return
            }
            //如果缓存已存在，把key移动到最近的位置，更新字典
            if dict[key] != nil {
                let index = findArrIndex(value: key, arr: arr)
                if index != -1 {
                    moveForward(index: index, arr: &arr)
                    dict.updateValue(value, forKey: key)
                    return
                }
            }
            
            if arr.count == max {
                dict.removeValue(forKey: arr.first!)
                arr.removeFirst()//移除队头，时间复杂度是o(n)
            }
            dict.updateValue(value, forKey: key)
            arr.append(key)
        }
        
        func moveForward(index:Int,arr:inout [Int]) {
            let tmp = arr[index]
            for i in index..<arr.count-1 {
                arr[i] = arr[i+1]
            }
            arr[arr.count-1] = tmp
        }
        
        func findArrIndex(value:Int,arr:[Int]) -> Int {
            for i in 0..<arr.count {
                if value == arr[i] {
                    return i
                }
            }
            return -1
        }
        
        
    }


}
