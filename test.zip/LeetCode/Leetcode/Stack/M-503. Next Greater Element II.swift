/*
 503. Next Greater Element II
 Medium
 
 7694
 
 188
 
 Add to List
 
 Share
 Given a circular integer array nums (i.e., the next element of nums[nums.length - 1] is nums[0]), return the next greater number for every element in nums.
 
 The next greater number of a number x is the first greater number to its traversing-order next in the array, which means you could search circularly to find its next greater number. If it doesn't exist, return -1 for this number.
 
 
 
 Example 1:
 
 Input: nums = [1,2,1]
 Output: [2,-1,2]
 Explanation: The first 1's next greater number is 2;
 The number 2 can't find next greater number.
 The second 1's next greater number needs to search circularly, which is also 2.
 Example 2:
 
 Input: nums = [1,2,3,4,3]
 Output: [2,3,4,-1,4]
 
 
 Constraints:
 
 1 <= nums.length <= 104
 -109 <= nums[i] <= 109
 */


private func nextGreaterElements(_ nums: [Int]) -> [Int] {
    let n = nums.count
    var stack = [Int]() // 用于存储尚未找到下一个更大元素的元素的索引的栈
    var result = Array(repeating: -1, count: n) // 初始化结果数组，初始值为-1
    
    for i in 0..<2 * n { // 两次遍历数组
        let modulo = i % n
        let num = nums[modulo] // 使用模运算来确保第二次遍历时可以重新回到数组的起始位置
        
        while !stack.isEmpty && nums[stack.last!] < num { // 当栈不为空且当前数字大于栈顶元素对应的数字时
            result[stack.removeLast()] = num // 更新栈顶元素对应的结果为当前数字，并将栈顶元素出栈
        }
        
        if i < n { // 如果仍在第一次遍历中，即考虑原始数组的元素时
            stack.append(i) // 将当前索引入栈
        }
    }
    
    return result // 返回结果数组，其中包含每个元素的下一个更大的元素
}
