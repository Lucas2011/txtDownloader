/*
 84. Largest Rectangle in Histogram
 Given an array of integers heights representing the histogram's bar height where the width of each bar is 1, return the area of the largest rectangle in the histogram.

  

 Example 1:


 Input: heights = [2,1,5,6,2,3]
 Output: 10
 Explanation: The above is a histogram where width of each bar is 1.
 The largest rectangle is shown in the red area, which has an area = 10 units.
 Example 2:


 Input: heights = [2,4]
 Output: 4
  

 Constraints:

 1 <= heights.length <= 105
 0 <= heights[i] <= 104
 */



private func largestRectangleArea(_ heights: [Int]) -> Int {
    var len = heights.count
    if len == 0 {return 0}
    if len == 1 {return heights[0]}
    
    var area = 0
    var stack = [Int]()
    
    /*
     使用哨兵 Sentine ,避免特殊情况的讨论
     */
    var heights = heights
    heights.append(0)
    heights.insert(0, at: 0)
    len += 2
    stack.append(0)
    
    for index in 1 ..< len {
        
        while heights[stack.last!] > heights[index] {// 这个循环内 栈顶元素的高度 > 当前元素的高度
            //计算出 栈顶元素 勾勒出来的面积
            let height = heights[stack.removeLast()]
            let width = index - stack.last! - 1
            area = max(area, width * height)
        }
        stack.append(index)
    }
    
    
    
    return area
}


private func largestRectangleArea1(_ heights: [Int]) -> Int {
    let len = heights.count
    if len == 0 {return 0}
    if len == 1 {return heights[0]}
    
    var area = 0
    var stack = [Int]()
    
    /*
     使用哨兵 Sentine ,避免特殊情况的讨论
     */
    
    
    
    for index in heights.indices {
        
        
        while !stack.isEmpty && heights[stack.last!] < heights[index] {// 这个循环内 当前元素的高度 小于 栈顶元素的高度 出栈
            //计算出 栈顶元素 勾勒出来的面积
            let height = heights[stack.removeLast()]
            while !stack.isEmpty && heights[stack.last!] == height {
                stack.popLast()
            }
            let width = stack.isEmpty ? index : index - stack.last! - 1
            area = max(area, width * height)
            
        }
        
        stack.append(index)
    }
    
    while !stack.isEmpty {// 这个循环内 当前元素的高度 小于 栈顶元素的高度 出栈
        //计算出 栈顶元素 勾勒出来的面积
        let height = heights[stack.removeLast()]
        while !stack.isEmpty && heights[stack.last!] == height {
            stack.popLast()
        }
        let width = stack.isEmpty ? len : len - stack.last! - 1
        area = max(area, width * height)
        
    }
    
    
    
    
    return area
}


private func largestRectangleArea2(_ heights: [Int]) -> Int {
    var max = 0
    
    for i in heights.indices {
        
        var currentMax = heights[i]
        var min = heights[i]
        for j in i+1 ..< heights.count {
            
            if heights[i] <= heights[j] {
                currentMax += min
            }else{
                break
            }
            
        }
        
        if i != 0 {
            for j in stride(from: i-1, through:0, by: -1){
                if heights[i] <= heights[j] {
                    currentMax += min
                }else{
                    break
                }
            }
        }
        
        max = max > currentMax ? max : currentMax
        
        
        
    }
    
    return max
}
