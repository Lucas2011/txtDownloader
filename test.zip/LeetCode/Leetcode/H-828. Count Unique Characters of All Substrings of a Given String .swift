/*
 828. Count Unique Characters of All Substrings of a Given String
 Hard
 
 1269
 
 172
 
 Add to List
 
 Share
 Let's define a function countUniqueChars(s) that returns the number of unique characters on s.
 
 For example, calling countUniqueChars(s) if s = "LEETCODE" then "L", "T", "C", "O", "D" are the unique characters since they appear only once in s, therefore countUniqueChars(s) = 5.
 Given a string s, return the sum of countUniqueChars(t) where t is a substring of s.
 
 Notice that some substrings can be repeated so in this case you have to count the repeated ones too.
 
 
 
 Example 1:
 
 Input: s = "ABC"
 Output: 10
 Explanation: All possible substrings are: "A","B","C","AB","BC" and "ABC".
 Every substring is composed with only unique letters.
 Sum of lengths of all substring is 1 + 1 + 1 + 2 + 2 + 3 = 10
 Example 2:
 
 Input: s = "ABA"
 Output: 8
 Explanation: The same as example 1, except countUniqueChars("ABA") = 1.
 Example 3:
 
 Input: s = "LEETCODE"
 Output: 92
 */
func uniqueLetterString(_ s: String) -> Int {
    var dict:[Character:[Int]] = [:]
    var arrayS = Array(s)
    var res = 0
    
    for i in 0..<arrayS.count{
        if dict[arrayS[i]] == nil{
            dict[arrayS[i]] = [0, i]
        }else{
res += (dict[arrayS[i]]!.last! - dict[arrayS[i]]!.first! + 1) * (i - dict[arrayS[i]]!.last!)
            dict[arrayS[i]]![0] = dict[arrayS[i]]!.last! + 1
            dict[arrayS[i]]![1] = i
        }
    }
    for value in dict.values{
        res += (value.last! - value.first! + 1) * (arrayS.count - value.last!)
    }
    
    /*Very large numbers will exceed the range of integer types,
     so I compute the result modulo 1000000007,
     ›which can be achieved by reducing the intermediary results
     modulo 1000000007 whenever they exceed or equal this value*/
    return res % 1000000007
}


/*
 It does not contain three repeating characters in a row (i.e., "...aaa..." is weak
 Input: password = "a"
 Output: 5
 */
func strongPasswordChecker(_ password: String) -> Int {
        let pass = Array(password), c = pass.count
        var low = false, up = false, num = false
        for c in pass {
            if c.isLowercase { low = true }
            else if c.isUppercase { up = true }
            else if c.isNumber { num = true }
        }
        var types = 3
        if low { types -= 1 }
        if up { types -= 1 }
        if num { types -= 1 }
        
        var one = 0, two = 0, rep = 0, i = 2
        while i < c {
            if pass[i] == pass[i-1] && pass[i] == pass[i-2] {
                var length = 2
                while i < c && pass[i] == pass[i-1] {
                    length += 1
                    i += 1
                }
                rep += length/3
                if length % 3 == 0 { one += 1 }
                else if length % 3 == 1 { two += 1 }
            } else {
                i += 1
            }
        }
        if c < 6 {
            return max(types, 6 - c)
        } else if c <= 20 {
            return max(types, rep)
        }
        let del = c - 20
        rep -= min(del, one)
        rep -= (min(max(del - one, 0), two * 2) / 2)
        rep -= (max(del - one - 2 * two, 0) / 3)
        return max(types, rep) + del
    }
