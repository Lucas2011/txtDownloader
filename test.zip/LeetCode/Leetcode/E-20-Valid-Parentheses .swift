/*
 Given a string s containing just the characters '(', ')', '{', '}', '[' and ']', determine if the input string is valid.
 
 An input string is valid if:
 
 Open brackets must be closed by the same type of brackets.
 Open brackets must be closed in the correct order.
 
 
 Example 1:
 
 Input: s = "()"
 Output: true
 Example 2:
 
 Input: s = "()[]{}"
 Output: true
 Example 3:
 
 Input: s = "(]"
 Output: false
 Example 4:
 
 Input: s = "([)]"
 Output: false
 Example 5:
 
 Input: s = "{[]}"
 Output: true
 创建一个dict和 stack array,
 dict key == nil,stack 添加 key
 dict key != nil, stack.popLast() == key? 
 
 */



private func isValid(_ s: String) -> Bool {
    
    let map:[Character:Character] = [
        "}":"{",
        ")":"(",
        "]":"[",
    ]
    
    var stack = [Character]()
    
    for str in s{
        
        let c = map[str]
        if c == nil{
            stack.append(str)
        }else{
            if stack.popLast() != c{
                return false
            }
        }
    }
    
    return stack.count == 0
    
}
