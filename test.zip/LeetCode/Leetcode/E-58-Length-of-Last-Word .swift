/*
 Given a string s consists of some words separated by spaces, return the length of the last word in the string. If the last word does not exist, return 0.
 
 A word is a maximal substring consisting of non-space characters only.
 
 
 
 Example 1:
 
 Input: s = "Hello World"
 Output: 5
 Example 2:
 
 Input: s = " "
 Output: 0
 
 
 Constraints:
 
 1 <= s.length <= 104
 s consists of only English letters and spaces ' '.
 
 */

private func lengthOfLastWord_Solution1(_ s: String) -> Int {
    var count = 0
    var next = false
    for i in s.reversed(){
        
        if (next){
            if i == " " {return count
            }else{
                count += 1
                continue
            }
        }
        
        if i != " " {
            count += 1
            next = true
        }
    }
    
    return count
}



private func lengthOfLastWord_Solution2(_ s: String) -> Int {
    if let lastWord = s.components(separatedBy: " ").filter({$0 == " "}).last{
        return lastWord.count
    }else{
        return 0
    }
    
}

