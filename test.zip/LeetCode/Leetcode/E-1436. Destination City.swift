/*
 You are given the array paths, where paths[i] = [cityAi, cityBi] means there exists a direct path going from cityAi to cityBi. Return the destination city, that is, the city without any path outgoing to another city.
 
 It is guaranteed that the graph of paths forms a line without any loop, therefore, there will be exactly one destination city.
 
 
 
 Example 1:
 
 Input: paths = [["London","New York"],["New York","Lima"],["Lima","Sao Paulo"]]
 Output: "Sao Paulo"
 Explanation: Starting at "London" city you will reach "Sao Paulo" city which is the destination city. Your trip consist of: "London" -> "New York" -> "Lima" -> "Sao Paulo".
 Example 2:
 
 Input: paths = [["B","C"],["D","B"],["C","A"]]
 Output: "A"
 Explanation: All possible trips are:
 "D" -> "B" -> "C" -> "A".
 "B" -> "C" -> "A".
 "C" -> "A".
 "A".
 Clearly the destination city is "A".
 */

/*
 讲 起点 和 终点 作为 key 添加到 dict , value 都是终点
 如果不存在 添加, 如果存在 移除
 最后只会剩下 最初的起点和终点位置
 compare key 和 value 如果相同
 就是目的地
 */
private func destCity(_ paths: [[String]]) -> String {
    var desDict = [String:String]()
    for s in paths{
        let sp = s.first!
        let ep = s.last!
        
        if desDict[ep] == nil{
            desDict[ep] = ep
        }else{
            desDict.removeValue(forKey: ep)
        }
        
        if desDict[sp] == nil{
            desDict[sp] = ep
        }else{
            desDict.removeValue(forKey: sp)
        }
        
    }
    for res in desDict.keys{
        if res == desDict[res]{
            return res
        }
    }
    return ""
}
