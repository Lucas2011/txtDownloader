/*
 3. Longest Substring Without Repeating Characters
 Medium
 
 23013
 
 1033
 
 Add to List
 
 Share
 Given a string s, find the length of the longest substring without repeating characters.
 
 
 
 Example 1:
 
 Input: s = "abcabcbb"
 Output: 3
 Explanation: The answer is "abc", with the length of 3.
 Example 2:
 
 Input: s = "bbbbb"
 Output: 1
 Explanation: The answer is "b", with the length of 1.
 Example 3:
 
 Input: s = "pwwkew"
 Output: 3
 Explanation: The answer is "wke", with the length of 3.
 Notice that the answer must be a substring, "pwke" is a subsequence and not a substring.
 */


//private func lengthOfLongestSubstring(_ s: String) -> Int {
//    // 算法边界不包含空字符串，判定返回
//    guard !s.isEmpty else { return 0 }
//
//    let cs = s.cString(using: .ascii)!
//    let len = strlen(cs)
//
//    // 初始化i和j
//    var i = 0
//    var j = 1
//
//    // cache存放遍历字符的位置
//    var cache: [Int] = Array(repeating: -1, count: 128)
//    var m = j - i
//    // cache保存着第一个字符的位置
//    cache[Int(cs[i])] = i
//    while j < len {
//        let k = cache[Int(cs[j])]
//        if k >= i {
//            // 当cache保存的字符位置在范围内，说明出现字符冲突
//            // 调整 i 让它往前跳
//            i = k + 1
//        }
//        cache[Int(cs[j])] = j
//        j += 1
//        // i被调整过后，或者没有冲突字符，新子串也是无重复子串
//        m = max(m, j-i)
//    }
//    return m
//}


private func lengthOfLongestSubstring_1(_ s: String) -> Int {
    guard s.count > 1 else { return s.count }
    var highestCount = 0
    var currentSubstring: [Character] = []
    
    for char in s {
        if let index = currentSubstring.firstIndex(of: char) {
            currentSubstring.removeFirst(index+1)
        }
        currentSubstring.append(char)
        highestCount = max(highestCount, currentSubstring.count)
    }
    return highestCount
}
