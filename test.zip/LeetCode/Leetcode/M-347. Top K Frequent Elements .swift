/*
 347. Top K Frequent Elements
 Medium

 8923

 363

 Add to List

 Share
 Given an integer array nums and an integer k, return the k most frequent elements. You may return the answer in any order.

  

 Example 1:

 Input: nums = [1,1,1,2,2,3], k = 2
 Output: [1,2]
 Example 2:

 Input: nums = [1], k = 1
 Output: [1]
 */

private func topKFrequent(_ nums: [Int], _ k: Int) -> [Int] {
    if nums.count == 0 {
        return []
    }
    if k > nums.count-1 {
        return nums
    }
    var result: [Int] = []
    var map: [Int: Int] = [:]
    for num in nums {
        map[num, default:0] += 1
    }
    var ct = k
    while ct > 0 {
        let highestCount = map.max { a, b in a.value < b.value }
        result.append(highestCount!.key)
        map[highestCount!.key] = 0
        ct -= 1
    }
    return result
}
