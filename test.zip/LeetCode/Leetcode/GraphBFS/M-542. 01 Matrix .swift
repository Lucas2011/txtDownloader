//
//  M-542. 01 Matrix .swift
//  leetcode
//
//  Created by Lucas on 12/1/21.
//  Copyright © 2021 Lucas. All rights reserved.
//

/*
 Given an m x n binary matrix mat, return the distance of the nearest 0 for each cell.
 
 The distance between two adjacent cells is 1.
 
 _______
 |0|0|0|
 _______
 |0|1|0|
 _______
 |0|0|0|
 
 Example 1:
 
 
 Input: mat = [[0,0,0],[0,1,0],[0,0,0]]
 Output: [[0,0,0],[0,1,0],[0,0,0]]
 Example 2:
 _______
 |0|0|0|
 _______
 |0|1|0|
 _______
 |1|1|1|
 
 Input: mat = [[0,0,0],[0,1,0],[1,1,1]]
 Output: [[0,0,0],[0,1,0],[1,2,1]]
 
 */

/*
 
 1. initlize a queue with all 0 nodes, a boolean [][] to revord visited nodes;
 2. while queue is not empty
     a.  retrieve current quque size as NUMBER OF NODES IN THE CURRENT LEVEL
 b. for each node in current level
     i.pull out one node
     #ii. if this is the node we want, return it
     ii. add all its neighbor to the queue IF NOT VISITED AND VAILED (in bound)
 c. increase level
 
 Time:O(m) Space: O(m)
 */


class No542_Solution1 {

private func updateMatrix(_ mat: [[Int]]) -> [[Int]] {
    
    if mat.count == 0 {return [[Int]]() }
    
    let m =  mat.count, n = mat[0].count, directions = [[1,0],[0,-1],[-1,0],[0,1]]
    var queue = [[Int]](), isVisited = [[Bool]](repeating: [Bool](repeating: false, count: n), count: m)
    var res = [[Int]](repeating: [Int](repeating: 0, count: n), count: m)
    
//    var res = Array(repeating: Array(repeating: 0, count: m), count: n)
//    var visted = Array(repeating: Array(repeating: false, count: m), count: n)


    for i in 0 ..< m{
        for j in 0 ..< n{
            if mat[i][j] == 0{
                queue.append([i,j])
                isVisited[i][j] = true
            }
        }
    }
    
    var cost = 0
    
    while !queue.isEmpty{
        print(queue)
        let size = queue.count
        
        for _ in 0 ..< size{
            let cur = queue.removeFirst()
            
            let i = cur[0], j = cur[1]
            if (mat[i][j] == 1){
                res[i][j] = cost
            }
            
            for dir in directions{
                let x = dir[0] + i , y = dir[1] + j
                if (x >= 0 && x < m && y >= 0 && y < n && !isVisited[x][y]){
                    queue.append([x,y])
                    isVisited[x][y] = true
                }

            }
            
            

        }
        
        

        cost += 1
        
        
        
    }
    
    return res
 }
}
