/*
 
 Given an array of integers nums and an integer target, return indices of the two numbers such that they add up to target.

 You may assume that each input would have exactly one solution, and you may not use the same element twice.

 You can return the answer in any order.

  

 Example 1:

 Input: nums = [2,7,11,15], target = 9
 Output: [0,1]
 Output: Because nums[0] + nums[1] == 9, we return [0, 1].
 Example 2:

 Input: nums = [3,2,4], target = 6
 Output: [1,2]
 Example 3:

 Input: nums = [3,3], target = 6
 Output: [0,1]

 
 特点 有序数组,且 只包含唯一答案
 */




private func twoSum(array:[Int],keyNumber:Int) -> (Int,Int){
    if keyNumber < array[0] {return (0,0)}
    var minIndex = 0
    var maxIndex = array.count-1
    var sumTotal = 0
  //move point from ether end - linear
  //首尾相加 大,尾部-1 ,小,首部+1
    while minIndex<maxIndex {
        sumTotal =  array[minIndex] + array[maxIndex]
        
        if sumTotal > keyNumber
        {
            maxIndex -= 1
        }else if sumTotal < keyNumber
        {
            minIndex += 1
        }else if sumTotal == keyNumber
        {
            return (array[minIndex],array[maxIndex])
        }
        
    }
    return (0,0)
}




