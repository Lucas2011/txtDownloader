/*
 A transformation sequence from word beginWord to word endWord using a dictionary wordList is a sequence of words beginWord -> s1 -> s2 -> ... -> sk such that:
 
 Every adjacent pair of words differs by a single letter.
 Every si for 1 <= i <= k is in wordList. Note that beginWord does not need to be in wordList.
 sk == endWord
 Given two words, beginWord and endWord, and a dictionary wordList, return the number of words in the shortest transformation sequence from beginWord to endWord, or 0 if no such sequence exists.
 
 
 
 Example 1:
 
 Input: beginWord = "hit", endWord = "cog", wordList = ["hot","dot","dog","lot","log","cog"]
 Output: 5
 Explanation: One shortest transformation sequence is "hit" -> "hot" -> "dot" -> "dog" -> cog", which is 5 words long.
 Example 2:
 
 Input: beginWord = "hit", endWord = "cog", wordList = ["hot","dot","dog","lot","log"]
 Output: 0
 Explanation: The endWord "cog" is not in wordList, therefore there is no valid transformation sequence.
 
 */


/*
 1. constructGraph graph
 a. if word1 and word2 are one char change away, then word1 and word2 are connected by edge 无向图
 
 1. initlize a queue with BEGGIN Word, a HashSet wo record visited words
 2. while queue is not empty
 a.  retrieve current quque size as NUMBER OF WORDS IN THE CURRENT LEVEL
 b. for each node in current level
 i.pull out one word
 ii. if this is the node we want, return it
 ii. add all its neighbor to the queue IF NOT VISITED AND VAILED (in bound)
 c. increase level
 
 */

class No127_Solution1{
    
    private func ladderLength(_ beginWord: String, _ endWord: String, _ wordList: [String]) -> Int {
        if !wordList.contains(endWord) {return 0}
        var wordList = wordList
        if !wordList.contains(beginWord) {
            wordList.insert(beginWord, at: 0)
        }
        let graph = constructGraph(worldList: wordList)
        var visited = [String]()
        var queue = [String]()
        visited.append(beginWord)
        queue.append(beginWord)
        
        var cost = 1
        while !queue.isEmpty{
            let size = queue.count
            
            for _ in 0..<size {
                let curr = queue.removeFirst()
                if (curr == endWord){
                    return cost
                }
                
                let oneLeeterArray = graph[curr]!
                
                for neighbor in oneLeeterArray{
                    if (!visited.contains(neighbor)){
                        visited.append(neighbor)
                        queue.append(neighbor)
                    }
                }
            }
            
            cost += 1
            
        }
        
        return 0
    }
    
    private func constructGraph(worldList:[String]) -> [String:[String]]{
        var graph = [String:[String]](), n = worldList.count
        for i in 0 ..< n-1{
            for j in i+1 ..< n{
                let w1 = worldList[i], w2 = worldList[j]
                if (oneChangeAway(w1, w2)){
                    var array1 = (graph[w1] != nil) ? graph[w1]! : [String]()
                    array1.append(w2)
                    graph.updateValue(array1, forKey: w1)
                    
                    var array2 = (graph[w2] != nil) ? graph[w2]! : [String]()
                    array2.append(w1)
                    
                    graph.updateValue(array2, forKey: w2)
                }
            }
        }
        return graph
    }
    private func oneChangeAway (_ w1:String, _ w2:String) -> Bool{
        if w1.count != w2.count {return false}
        
        var diff = 0
        for i in 0 ..< w1.count{
            
            let c1 = w1[w1.index(w1.startIndex, offsetBy: i)]
            let c2 = w2[w2.index(w2.startIndex, offsetBy: i)]
            if c1 != c2 {
                diff += 1
            }
            
        }
        
        return diff == 1
    }
    
    
    
}

