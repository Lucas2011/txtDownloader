/*
 Given an integer array nums, move all 0's to the end of it while maintaining the relative order of the non-zero elements.
 
 Note that you must do this in-place without making a copy of the array.
 
 
 
 Example 1:
 
 Input: nums = [0,1,0,3,12]
 Output: [1,3,12,0,0]
 Example 2:
 
 Input: nums = [0]
 Output: [0]
 */

func moveZeroes(_ nums: inout [Int]) {
    var i = 0, j = 0 , temp = 0
    
    while j < nums.count {
        
        if nums[j] == 0 {
            j += 1
        }else{
            temp = nums[i]
            nums[i] = nums[j]
            nums[j] = temp
            
            i += 1
            j += 1
        }
        
    }
}

/*
 这里参考了快速排序的思想，快速排序首先要确定一个待分割的元素做中间点 x，然后把所有小于等于 x 的元素放到 x 的左边，大于 x 的元素放到其右边。
 这里我们可以用 0 当做这个中间点，把不等于 0(注意题目没说不能有负数)的放到中间点的左边，等于 0 的放到其右边。
 这的中间点就是 0 本身，所以实现起来比快速排序简单很多，我们使用两个指针 i 和 j，只要 nums[i]!=0，我们就交换 nums[i] 和 nums[j]

 作者：王尼玛
 链接：https://leetcode.cn/problems/move-zeroes/solutions/90229/dong-hua-yan-shi-283yi-dong-ling-by-wang_ni_ma/
 来源：力扣（LeetCode）
 著作权归作者所有。商业转载请联系作者获得授权，非商业转载请注明出处。
 */
func moveZeroes2(_ nums: inout [Int]) {
    var j = 0
    
    for i in 0 ..< nums.count {
        //[0,1,0,3,12]
        if nums[i] != 0 {
            let tmp = nums[i];
            nums[i] = nums[j];
            nums[j] = tmp;
            j += 1
        }
        
    }
    
}
