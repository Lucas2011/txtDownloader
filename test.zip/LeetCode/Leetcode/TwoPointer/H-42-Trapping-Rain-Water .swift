/*
 42. Trapping Rain Water
 Given n non-negative integers representing an elevation map where the width of each bar is 1, compute how much water it can trap after raining.
 
 Input: height = [0,1,0,2,1,0,1,3,2,1,2,1]
 Output: 6
 Explanation: The above elevation map (black section) is represented by array [0,1,0,2,1,0,1,3,2,1,2,1]. In this case, 6 units of rain water (blue section) are being trapped.
 Example 2:
 
 Input: height = [4,2,0,3,2,5]
 Output: 9
 
 
 */

    func trap1(_ height: [Int]) -> Int {
        var left = 0 , right = height.count - 1 ,maxLeft = height[left] , maxRight = height[right] , ans = 0
       
        while left < right {
            if height[left] <= height[right] {
                if (height[left] > maxLeft){
                    maxLeft = height[left]
                }
                if (maxLeft - height[left] > 0){
                    ans += maxLeft - height[left]
                }
                left += 1
            }else{
                if (height[right] > maxRight){
                    maxRight = height[right]
                }
                if (maxRight - height[right] > 0){
                    ans += maxRight - height[right]
                }
                right -= 1
                
            }
        }
        return ans
        
    }
    
    func trap2(_ height: [Int]) -> Int {
        var maxLeft = [Int](),maxRight = [Int](),min = 0,ans = 0
       
        for nums in height{
            if nums >= min{
                maxLeft.append(min)
                min = nums
            }else{
                maxLeft.append(min)
            }
        }
       
        min = 0
        for i in stride(from: height.count - 1, to: -1, by: -1){
            if height[i] >= min{
                maxRight.insert(height[i], at: 0)
                min = height[i]
            }else{
                maxRight.insert(min, at: 0)
            }
            
        }

        for i in 0 ... height.count - 1 {
            min = maxLeft[i] > maxRight[i] ? maxRight[i] : maxLeft[i]
            ans += min - height[i] > 0 ? min - height[i] : 0
        }
        return ans
    }
        

