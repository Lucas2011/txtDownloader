/*
 1047. Remove All Adjacent Duplicates In String
 
 You are given a string s consisting of lowercase English letters. A duplicate removal consists of choosing two adjacent and equal letters and removing them.
 
 We repeatedly make duplicate removals on s until we no longer can.
 
 Return the final string after all such duplicate removals have been made. It can be proven that the answer is unique.
 
 Example 1:
 
 Input: s = "abbaca"
 Output: "ca"
 Explanation:
 For example, in "abbaca" we could remove "bb" since the letters are adjacent and equal, and this is the only possible move.  The result of this move is that the string is "aaca", of which only "aa" is possible, so the final string is "ca".
 Example 2:
 
 Input: s = "azxxzy"
 Output: "ay"
 */



//two pointer
private func removeDuplicates_1(_ s: String) -> String {
    
    var array = Array(s)
    
    var i = 0 , j = 0
    
    while j < array.count {
        if i == 0 || array[i-1] != array[j]{
            array[i] = array[j]
            i += 1
            j += 1
        }else{
            j += 1
            i -= 1
        }
        
    }
    return i == 0 ? "" : String(array[0...i-1])
}

//stack
private func removeDuplicates(_ s: String) -> String {
    var res = String()
    for char in s {
        
        if res.isEmpty || res.last != char{
            res.append(char)
        }else{
            _ = res.popLast()
        }
        
    }
    return res
}

