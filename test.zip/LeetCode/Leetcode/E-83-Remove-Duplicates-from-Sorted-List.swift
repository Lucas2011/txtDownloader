/*
 Given the head of a sorted linked list, delete all duplicates such that each element appears only once. Return the linked list sorted as well.
 
 Input: head = [1,1,2]
 Output: [1,2]
 
 Input: head = [1,1,2,3,3]
 Output: [1,2,3]
 
 利用 node = head引用传递 来清理 node 的值
 */


private func deleteDuplicates(_ head: ListNode?) -> ListNode? {
    var node = head
    while node != nil {
        if node?.val == node?.next?.val{
            node?.next = node?.next?.next
        }else{
            node = node?.next
        }
        
    }
    
    
    
    return head
    
}

