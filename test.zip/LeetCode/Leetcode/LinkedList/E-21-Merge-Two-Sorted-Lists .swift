/*
 
 Merge two sorted linked lists and return it as a new sorted list. The new list should be made by splicing together the nodes of the first two lists.
 
 Example 1:
 Input: l1 = [1,2,4], l2 = [1,3,4]
 Output: [1,1,2,3,4,4]
 Example 2:
 
 Input: l1 = [], l2 = []
 Output: []
 Example 3:
 
 Input: l1 = [], l2 = [0]
 Output: [0]
 
 */


/**
 比对两组串列值，若 l1 < l2 则当前答案串列摆入 l1 ，并且将 l1.next 与没有摆入的​​ l2 带入下一个 next 比较。
 若相反，将 l2 放进答案串列，并且将 l2.next 与没有摆入的​​ l1 带入下一个 next 比较。
 直至某一方先到底，就将另一方剩下的串列都放进答案串列中。
 */

//public class ListNode {
//    public var val: Int
//    public var next: ListNode?
//    public init() { self.val = 0; self.next = nil; }
//    public init(_ val: Int) { self.val = val; self.next = nil; }
//    public init(_ val: Int, _ next: ListNode?) { self.val = val; self.next = next; }
//}

//Lucas

private func mergeTwoLists(_ l1: ListNode?, _ l2: ListNode?) -> ListNode? {
    if l1 == nil { return l2 }
    if l2 == nil { return l1 }
    
    if l1!.val < l2!.val {
        l1!.next = mergeTwoLists(l1!.next, l2)
        return l1
    } else {
        l2!.next = mergeTwoLists(l2!.next, l1)
        return l2
    }
}

/**
虚拟一个头节点
 */
private func mergeTwoLists2(_ list1: ListNode?, _ list2: ListNode?) -> ListNode? {
    
    var dummy = ListNode(0),current: ListNode? = dummy, l1 = list1, l2 = list2
    
    
    
    while l1 != nil && l2 != nil {
        
        if l1!.val < l2!.val {
            current?.next = l1
            l1 = l1?.next
        }else{
            current?.next = l2!
            l2 = l2?.next
        }
        current = current?.next
        
        
    }
    
    if l1 != nil {
        current?.next = l1
    } else {
        current?.next = l2
    }
    
    
    
    return dummy.next
    
}
