/*
 Given the head of a linked list, rotate the list to the right by k places.
 
 
 
 Example 1:
 
 
 Input: head = [1,2,3,4,5], k = 2
 [5,1,2,3,4] ->  [4,5,1,2,3]
 
 Output: [4,5,1,2,3]
 Example 2:
 
 
 Input: head = [0,1,2], k = 4
 
 /
 
 
 思路.
 1. 链表总长度 n, k % n = 需要反转的次数, 例如 1,2,3,4,5, k = 7, n = 5, 实际结果是 [4,5,1,2,3]
 7%5 = 2 , 5 - 2 = 3 所以 3 是最后的 tail
 
 PreNode P of the new head : n - k - 1 = 3
 NewHead: 4
 TailNode: 5
 
 1.NewHead = PreNode.next
 2.PreNode.next = nil
 3.Tail.next = head
 return NewHead
 
 */

private func rotateRight(_ head: ListNode?, _ k: Int) -> ListNode? {
    if head == nil {return head}
    var tail = head, length = 1
    
    while tail?.next != nil {
        tail = tail?.next
        length += 1
    }
    
    let remainder = k % length
    
    if remainder == 0 {return head}
    
    var preNode = head
    
    
    for _ in 0 ..< length - remainder - 1 {
        preNode = preNode?.next
    }
    
    var newHead = preNode?.next
    preNode?.next = nil
    tail?.next = head
    
    
    return newHead
    
}
