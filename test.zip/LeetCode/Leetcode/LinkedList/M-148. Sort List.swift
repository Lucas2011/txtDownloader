/*
 148. Sort List
 Medium
 
 11184
 
 333
 
 Add to List
 
 Share
 Given the head of a linked list, return the list after sorting it in ascending order.
 
 
 
 Example 1:
 
 
 Input: head = [4,2,1,3]
 Output: [1,2,3,4]
 Example 2:
 
 
 Input: head = [-1,5,3,4,0]
 Output: [-1,0,3,4,5]
 Example 3:
 
 Input: head = []
 Output: []
 */


private func sortList(_ head: ListNode?) -> ListNode? {
    if head == nil || head?.next == nil {return head}
    let midNode = getForwardedMidNode(node: head)
    let next = midNode?.next
    midNode?.next = nil  // Split the list into two halves
    
    // Recursively sort each half of the list
    let left = sortList(head)
    let right = sortList(next)
    
    return merge(left, right)
    
}

func merge(_ left:ListNode?,_ right:ListNode?) -> ListNode? {
    
    let dummy = ListNode(0)
    var current = dummy,leftPtr = left, rightPtr = right
    
    while leftPtr != nil && rightPtr != nil {
        if (leftPtr!.val <= rightPtr!.val){
            current.next = leftPtr
            leftPtr = leftPtr?.next
        }else{
            current.next = rightPtr
            rightPtr = rightPtr?.next
        }
        
        current = current.next!
    }
    
    current.next = leftPtr ?? rightPtr
    
    
    return dummy.next
}


