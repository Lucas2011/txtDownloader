/*
找 linked list 的中间节点
 */

private func linkedListMiddleNode(_ head: ListNode) -> ListNode {
    var i = head, j = head
    
    while j != nil && j.next != nil {
        i = head.next!
        j = head.next!.next!
    }
    
    return i
}
