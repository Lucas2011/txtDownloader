/*
 25. Reverse Nodes in k-Group
 
 Given the head of a linked list, reverse the nodes of the list k at a time, and return the modified list.
 
 k is a positive integer and is less than or equal to the length of the linked list. If the number of nodes is not a multiple of k then left-out nodes, in the end, should remain as it is.
 
 You may not alter the values in the list's nodes, only nodes themselves may be changed.
 
 
 
 
 Example 1:
 
 
 Input: head = [1,2,3,4,5], k = 2
 Output: [2,1,4,3,5]
 Example 2:
 
 
 Input: head = [1,2,3,4,5], k = 3
 Output: [3,2,1,4,5]
 */
/*
k 代表 一次反转数量 ,
 例如  1,2,3,4,5, k = 2, 反正 2 * n, 剩余的不翻转
 
 */
private func reverseKGroup(_ head: ListNode?, _ k: Int) -> ListNode? {
    var pre = ListNode(0),current = 1
    pre.next = head
    
    while pre.next != nil {
        pre = pre.next!
        
        if (current % k == 0) {
            reveseNode(head, current-k+1, current)
        }
        current += 1
    }
    
    return head
    
}

/*
 92. Reverse Linked List II 
 */
private func reveseNode(_ head:ListNode?,_ left:Int,_ right:Int ) ->ListNode?{ 
    var left = left , right = right
    
    while left <= right {
        
        var leftNode = head, rightNode = head
        
        for i in 0 ..< right - 1 {
            if i < left - 1 {
                leftNode = leftNode?.next
            }
            rightNode = rightNode?.next
        }
        
        let tem = rightNode?.val
        rightNode?.val = leftNode!.val
        
        leftNode?.val = tem!
        
        
        left += 1
        right -= 1
    }
    
    return head
}
