/*
 You are given two non-empty linked lists representing two non-negative integers. The most significant digit comes first and each of their nodes contains a single digit. Add the two numbers and return the sum as a linked list.
 
 You may assume the two numbers do not contain any leading zero, except the number 0 itself.
 
 
 
 Example 1:
 
 
 Input: l1 = [7,2,4,3], l2 = [5,6,4]
 Output: [7,8,0,7]
 Example 2:
 
 Input: l1 = [2,4,3], l2 = [5,6,4]
 Output: [8,0,7]
 Example 3:
 
 Input: l1 = [0], l2 = [0]
 Output: [0]
 */

private func reverseList(_ head: ListNode?) -> ListNode? {
    var prev: ListNode? = nil
    var current = head
    
    while current != nil {
        let next = current?.next
        current?.next = prev
        prev = current
        current = next
    }
    
    return prev
}

private func addTwoNumbers(_ l1: ListNode?, _ l2: ListNode?) -> ListNode? {
    // Reverse both input linked lists
    let reversedL1 = reverseList(l1)
    let reversedL2 = reverseList(l2)
    
    var carry = 0
    var result: ListNode?
    var current1 = reversedL1
    var current2 = reversedL2
    
    while current1 != nil || current2 != nil || carry > 0 {//*******
        let sum = (current1?.val ?? 0) + (current2?.val ?? 0) + carry
        carry = sum / 10
        let digit = sum % 10
        
        let newNode = ListNode(digit) //*******
        newNode.next = result//*******
        result = newNode//*******
        
        current1 = current1?.next
        current2 = current2?.next
    }
    
    return result
}
