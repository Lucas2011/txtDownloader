/*
 Given the head of a linked list, remove the nth node from the end of the list and return its head.

  

 Example 1:


 Input: head = [1,2,3,4,5], n = 2
 Output: [1,2,3,5]
 Example 2:

 Input: head = [1], n = 1
 Output: []
 Example 3:

 Input: head = [1,2], n = 1
 Output: [1]

 */

/*
 构造虚拟头结点。可以使遍历处理逻辑更加统一。
 */

private func removeNthFromEnd(_ head: ListNode?, _ n: Int) -> ListNode? {
    let dummy = ListNode(0)
    dummy.next = head
    
    var fast: ListNode? = dummy
    var slow: ListNode? = dummy

    for i in 0 ... n  {
        fast = fast?.next
    }

    
    while fast != nil {
        fast = fast?.next
        slow = slow?.next
    }
    
    slow?.next = slow?.next?.next
    return dummy.next
    
}
