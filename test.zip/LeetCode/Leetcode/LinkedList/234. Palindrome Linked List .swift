/*
 Given the head of a singly linked list, return true if it is a palindrome or false otherwise.
 
 
 
 Example 1:
 
 
 Input: head = [1,2,2,1]
 Output: true
 Example 2:
 
 
 Input: head = [1,2]
 Output: false
 
 
 Constraints:
 
 The number of nodes in the list is in the range [1, 105].
 0 <= Node.val <= 9
 
 */
private func isPalindrome(_ head: ListNode?) -> Bool {
    // 边界情况：空链表或只有一个节点的链表是回文的
    guard head != nil, head?.next != nil else {
        return true
    }
    
    // 使用快慢指针找到链表中点
    var slow = head
    var fast = head
    while fast != nil, fast?.next != nil {
        slow = slow?.next
        fast = fast?.next?.next
    }
    
    // 反转后半部分链表
    var prev: ListNode? = nil
    var current = slow
    while current != nil {
        let next = current?.next
        current?.next = prev
        prev = current
        current = next
    }
    
    // 比较前半部分和反转后的后半部分链表
    var left = head
    var right = prev
    while right != nil {
        if left?.val != right?.val {
            return false
        }
        left = left?.next
        right = right?.next
    }
    
    return true
}
