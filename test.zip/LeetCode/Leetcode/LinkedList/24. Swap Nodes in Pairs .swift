/*
 Given a linked list, swap every two adjacent nodes and return its head. You must solve the problem without modifying the values in the list's nodes (i.e., only nodes themselves may be changed.)
 
 
 
 Example 1:
 
 
 Input: head = [1,2,3,4]
 Output: [2,1,4,3]
 Example 2:
 
 Input: head = []
 Output: []
 Example 3:
 
 Input: head = [1]
 Output: [1]
 
 */

/*
 这个解法使用了一个虚拟节点（dummy node）简化操作，然后通过迭代遍历链表，每次交换相邻的两个节点。这个过程中，需要更新节点的指针关系，包括当前节点（current）、第一个节点（first）、第二个节点（second）。具体的步骤如下：

 创建一个带有虚拟头节点的链表（dummy）来简化操作。
 使用 while 循环遍历链表，每次处理一对相邻的节点。
 对于每一对相邻节点，通过更新它们的 next 指针来完成节点的交换。
 更新 current 指针，使其指向已经完成交换的节点，以便继续下一对相邻节点的处理。
 返回虚拟头节点的 next，即新的链表头。
 这个算法的时间复杂度是 O(n)，其中 n 是链表的长度，因为它只对每个节点进行一次操作。这个解法在 Swift 中使用了可选链操作符 ? 来方便地处理可能为 nil 的情况。
 */

private func swapPairs(_ head: ListNode?) -> ListNode? {
//     func swapPairs(_ head: ListNode?) -> ListNode? {

    let dummy = ListNode(0)
    dummy.next = head
    var current: ListNode? = dummy
    // 1, 2, 3, 4, 5
    while let first = current?.next, let second = current?.next?.next {
        //first 1 2 3 4 5 current 0 1 2 3 4 5
        //second 2 3 4 5
        first.next = second.next //1 3 4 5
        second.next = first //2 1 3 4 5
        current?.next = second //0 2 1 3 4 5
        
        current = first //1 3 4 5
    }
    
    
    return dummy.next
}
