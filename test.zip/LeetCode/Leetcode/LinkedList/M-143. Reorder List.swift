/*
 You are given the head of a singly linked-list. The list can be represented as:
 
 L0 → L1 → … → Ln - 1 → Ln
 Reorder the list to be on the following form:
 
 L0 → Ln → L1 → Ln - 1 → L2 → Ln - 2 → …
 You may not modify the values in the list's nodes. Only nodes themselves may be changed.
 
 
 
 Example 1:
 
 
 Input: head = [1,2,3,4]
 Output: [1,4,2,3]
 Example 2:
 
 
 Input: head = [1,2,3,4,5]
 Output: [1,5,2,4,3]
 
 思路: 快慢指针拿到中间值 1st的长度永远是 小于等于 2nd
 1st 1 2 3 , 2nd 2 3 4
 
 反转 2nd
 
 拼接*
 */

private func reverseNode(_ head: ListNode?) -> ListNode? {
    
    var prev: ListNode? = nil,current = head
    
    while current != nil {
        let nextTemp = current?.next
        current?.next = prev
        prev = current
        current = nextTemp
    }
    
    return prev
}

private func reorderList(_ head: ListNode?) {
    if head == nil || head?.next == nil { return }
    
    // Find the middle of the linked list
    var slow = head,fast:ListNode? = head
    var prev: ListNode? = nil
    
    while fast?.next != nil {
        prev = slow
        slow = slow?.next!
        fast = fast?.next?.next
    }
    
    prev?.next = nil
    
    
    // Merge the two halves
    var first = head
    var second = reverseNode(slow)
    while second != nil {
        let nextFirst = first?.next
        let nextSecond = second!.next
        first?.next = second
        if nextFirst == nil {return}
        second!.next = nextFirst
        first = nextFirst!
        second = nextSecond
    }
    
}
