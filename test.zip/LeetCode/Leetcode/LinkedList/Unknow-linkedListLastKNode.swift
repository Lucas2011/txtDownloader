/*
找 linked list 的中间节点
 */

private func linkedListLastKNode(_ head: ListNode,_ k: Int) -> ListNode {
    var j = ListNode()
    for i in 0...k {
        j = head.next!
    }
    var i = head
    
    while j != nil && j.next != nil  {
        i = head.next!
        j = head.next!
    }
    
    return i
}
