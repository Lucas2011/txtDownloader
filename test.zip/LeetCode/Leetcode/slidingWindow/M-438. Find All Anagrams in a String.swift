/*
 438. Find All Anagrams in a String
 Medium
 
 7254
 
 251
 
 Add to List
 
 Share
 Given two strings s and p, return an array of all the start indices of p's anagrams in s. You may return the answer in any order.
 
 An Anagram is a word or phrase formed by rearranging the letters of a different word or phrase, typically using all the original letters exactly once.
 
 
 
 Example 1:
 
 Input: s = "cbaebabacd", p = "abc"
 Output: [0,6]
 Explanation:
 The substring with start index = 0 is "cba", which is an anagram of "abc".
 The substring with start index = 6 is "bac", which is an anagram of "abc".
 Example 2:
 
 Input: s = "abab", p = "ab"
 Output: [0,1,2]
 Explanation:
 The substring with start index = 0 is "ab", which is an anagram of "ab".
 The substring with start index = 1 is "ba", which is an anagram of "ab".
 The substring with start index = 2 is "ab", which is an anagram of "ab".
 */

private func findAnagrams(_ s: String, _ p: String) -> [Int] {
    let sCount = s.utf8.count
    let pCount = p.utf8.count
    guard sCount >= pCount else {
        return []
    }
    let a = Int(Unicode.Scalar("a").value)
    var map = [Int](repeating: 0, count: 26)
    p.utf8.forEach({
        print($0)
        map[Int($0) - a] += 1
    })
    let sArray = Array(s.utf8)
    var left = 0
    var right = 0
    var count = 0
    var res = [Int]()
    
    while right < sCount {
        let rightIndex = Int(sArray[right]) - a
        if map[rightIndex] > 0 {
            map[rightIndex] -= 1
            right += 1
            count += 1
        } else {
            let leftIndex = Int(sArray[left]) - a
            map[leftIndex] += 1
            left += 1
            count -= 1
        }
        if count == pCount {
            res.append(left)
        }
    }
    return res
}




//func findAnagrams(_ s: String, _ p: String) -> [Int] {
//    let n = s.count, l = p.count
//
//    let sArray = Array(s)
//    var pDict = [Character:Int]()
//    for char in p {
//        pDict[char] = pDict[char] == nil ? 1 : pDict[char]! + 1
//    }
//
//    var sDict = [Character:Int]()
//    var res = [Int]()
//
//    var starIndex = 0
//    for index in 0 ..< l {
//        sDict[sArray[index]] = sDict[sArray[index]] == nil ? 1 : sDict[sArray[index]]! + 1
//        if sDict.keys.count > p.count {
//            sDict.removeValue(forKey: sArray[starIndex])
//            starIndex += 1
//        }
//
//        if sDict == pDict{
//            res.append(starIndex)
//        }
//
//    }
//
//
//
//    return [0]
// }
