/*
 Given a binary tree, check whether it is a mirror of itself (ie, symmetric around its center).
 
 For example, this binary tree [1,2,2,3,4,4,3] is symmetric:
 
 1
 / \
 2   2
 / \ / \
 3  4 4  3
 
 
 But the following [1,2,2,null,3,null,3] is not:
 
 1
 / \
 2   2
 \   \
 3    3
 
 
 Follow up: Solve it both recursively and iteratively.
 
 
 */
/**
 * Definition for a binary tree node.
 * public class TreeNode {
 *     public var val: Int
 *     public var left: TreeNode?
 *     public var right: TreeNode?
 *     public init() { self.val = 0; self.left = nil; self.right = nil; }
 *     public init(_ val: Int) { self.val = val; self.left = nil; self.right = nil; }
 *     public init(_ val: Int, _ left: TreeNode?, _ right: TreeNode?) {
 *         self.val = val
 *         self.left = left
 *         self.right = right
 *     }
 * }
 */


/*
 从根节点左右开始验证，若左右皆为 nil 则为对称，若只有某一边 nil 则不为对称。
 
 若两边都存在，比对值是否相同，相同则继续往下比对，
 
 比对左子树的左节点，和右子树的右节点是否相同，
 
 再比对左子树的右节点，和右子树的左节点是否相同，
 
 直到结束，返回答案值。
 */

//lucas

private func isSymmetric(_ root: TreeNode?) -> Bool {
    return isSymmetricTree(root?.left, root?.right)
    
}


private func isSymmetricTree(_ p: TreeNode?, _ q: TreeNode?) -> Bool {
    if let p = p, let q = q {
        return p.val == q.val && isSymmetricTree(p.left, q.right) && isSymmetricTree(p.right, q.left)
    } else {
        return p == nil && q == nil
    }
}
