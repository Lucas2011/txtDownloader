
/*
 
 Implement strStr().
 
 Return the index of the first occurrence of needle in haystack, or -1 if needle is not part of haystack.
 
 Clarification:
 
 What should we return when needle is an empty string? This is a great question to ask during an interview.
 
 For the purpose of this problem, we will return 0 when needle is an empty string. This is consistent to C's strstr() and Java's indexOf().
 
 
 Example 1:
 
 Input: haystack = "hello", needle = "ll"
 Output: 2
 Example 2:
 
 Input: haystack = "aaaaa", needle = "bba"
 Output: -1
 Example 3:
 
 Input: haystack = "", needle = ""
 Output: 0
 
 
 
 */




private func strStr_Solution1(_ haystack: String, _ needle: String) -> Int {
    
    guard needle != "" else { return 0 }
    guard haystack.count >= needle.count else { return -1 }
    
    let s1Array = Array(haystack)
    let s2Array = Array(needle)
    
    //The length of s2 cannot be longer than s1
    for i in 0...s1Array.count - s2Array.count {
        if Array(s1Array[i...i + s2Array.count - 1]) == s2Array {
            return i
        }
    }
    return -1
}



//Time Limit Exceeded


private func strStr_Solution2(_ haystack: String, _ needle: String) -> Int {
    
    if needle.count > haystack.count {return -1}
    if needle == "" {return 0 }
    
    if let range = haystack.range(of: needle) {
        let index = haystack.distance(from: haystack.startIndex, to: range.lowerBound)
        // return NSRange(range, in: haystack).location
        return index
    }else {
        return -1
    }
    
}



//Time Limit Exceeded


private func strStr_Solution3(_ haystack: String, _ needle: String) -> Int {
    
    guard needle != "" else { return 0 }
    guard haystack.count >= needle.count else { return -1 }
    
    let s1Array = Array(haystack)
    let s2Array = Array(needle)
    
    for i in 0...s1Array.count - s2Array.count {
        
        for j in 0..<s2Array.count {
            if s1Array[i + j] != s2Array [j] {
                break
            }
            if i+s2Array.count - 1 > s1Array.count  {
                break
            }
            if (j == s2Array.count - 1) {
                return i
            }
        }
        
    }
    
    return -1
}


