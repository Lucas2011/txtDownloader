/*
 We are given some website visits: the user with name username[i] visited the website website[i] at time timestamp[i].

 A 3-sequence is a list of websites of length 3 sorted in ascending order by the time of their visits.  (The websites in a 3-sequence are not necessarily distinct.)

 Find the 3-sequence visited by the largest number of users. If there is more than one solution, return the lexicographically smallest such 3-sequence.

 Example 1:

 Input: username = ["joe","joe","joe","james","james","james","james","mary","mary","mary"], timestamp = [1,2,3,4,5,6,7,8,9,10], website = ["home","about","career","home","cart","maps","home","home","about","career"]
 Output: ["home","about","career"]
 Explanation:
 The tuples in this example are:
 ["joe", 1, "home"]
 ["joe", 2, "about"]
 ["joe", 3, "career"]
 ["james", 4, "home"]
 ["james", 5, "cart"]
 ["james", 6, "maps"]
 ["james", 7, "home"]
 ["mary", 8, "home"]
 ["mary", 9, "about"]
 ["mary", 10, "career"]
 The 3-sequence ("home", "about", "career") was visited at least once by 2 users.
 The 3-sequence ("home", "cart", "maps") was visited at least once by 1 user.
 The 3-sequence ("home", "cart", "home") was visited at least once by 1 user.
 The 3-sequence ("home", "maps", "home") was visited at least once by 1 user.
 The 3-sequence ("cart", "maps", "home") was visited at least once by 1 user.
 Note:

 3 <= N = username.length = timestamp.length = website.length <= 50
 1 <= username[i].length <= 10
 0 <= timestamp[i] <= 10^9
 1 <= website[i].length <= 10
 Both username[i] and website[i] contain only lowercase characters.
 It is guaranteed that there is at least one user who visited at least 3 websites.
 No user visits two websites at the same time.
 
 T1 C1 P1
 T2 C2 P2
 T3 C1 P2
 T4 C2 P1
 T5 C1 P1
 
 */

//Most Popular Page Sequence

/*
 Input: username = ["joe","joe","joe","james","james","james","james","mary","mary","mary"], timestamp = [1,2,3,4,5,6,7,8,9,10], website = ["home","about","career","home","cart","maps","home","home","about","career"]
 Output: ["home","about","career"]
 */

/*
 
 ["joe",    "home",     1],
 ["joe",    "about",    2],
 ["joe",    "career",   3],
 
 ["james",  "home",     4]
 ["james",  "cart",     5],
 ["james",  "maps",     6],
 ["james",  "home",     7],
 
 ["mary",   "home",     8],
 ["mary",   "about",    9]
 ["mary",   "career",    10].
 
 
 */

private func mostVisitedPattern(_ username: [String], _ timestamp: [Int], _ website: [String]) -> [String] {
        var websiteScore = [String: Set<String>]()
        var userHistory = [String: [(String, Int)]]()
        
        // First group data by user
        for i in 0..<username.count {
            userHistory[username[i], default: []].append((website[i], timestamp[i]))
        }
        
        // sort grouped data by timestamp
        userHistory.forEach { (user,data) in
            userHistory[user]?.sort{ $0.1 < $1.1 }
        }

        var pattern = [String]()
        
        // For every user generate patter and gather the website score for 3 visits
        for (user, data) in userHistory {
            if data.count < 3 { continue }
            patternCount(user, data, 0, &pattern, &websiteScore)
        }// home-cart-home : user/users

        let result = websiteScore
        .sorted { $0.value.count > $1.value.count
                || $0.value.count == $1.value.count && $0.key < $1.key }

        return result[0].key
            .split(separator: "-")
            .map(String.init)
    }

private func patternCount(_ user: String ,_ websites: [(String, Int)], _ start: Int , _ pattern: inout [String],_ websiteScore: inout [String: Set<String>]) {
    if pattern.count == 3 {
        websiteScore[pattern.joined(separator: "-"), default: []].insert(user)
    } else {
        if start < websites.count {
            for index in start...websites.count-1 {
                pattern.append(websites[index].0)
                patternCount(user, websites, index + 1, &pattern, &websiteScore)
                pattern.removeLast()
            }
        }
    }
}



// import Cocoa
//
//
//  func mostVisitedPattern( username:[String], timeStample:[Int], website: [String]) ->[String]{
//
//
//     var userWebsite = [String: [String]]()
//     for i in 0 ..< username.count {
//         let currentUser = username[i]
//         let currentWebsite = website[i]
//         userWebsite[currentUser, default: []].append(currentWebsite)
//     }
//     print(userWebsite)
//     // generate 3-sequences for each user // t: O(n*k), s: O(n) where n is number of users, k is number of sequences per user
//     var sequences = [[String]]()
//     let values = Array(userWebsite.values)
//     for value in values {
//         let numberOfSequences = value.count - 2 // 8 items will generate 6 3-sequences pairs
//         for i in 0..<numberOfSequences {
//             let subArray = Array(value[i..<i+3]) // get only three elements
//             sequences.append(subArray)
//         }
//     }
//
//     // get the max visited pair
//     var maxCount = 0
//     var maxVisited = [String]()
//     let set = NSCountedSet(array: sequences) // t: o(n), s:(n) where n is websites count
//
//     for item in set { // t: o(n), s:(n) where n is websites count
//         let count = set.count(for: item)
//         if maxCount > count {
//             maxCount = count
//             maxVisited = item as! [String]
//         }
//     }
//     return maxVisited
//
// }
//
