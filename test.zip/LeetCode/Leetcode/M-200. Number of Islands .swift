//
//  M-200. Number of Islands .swift
//  Leetcode
//
//  Created by Lucas on 3/16/22.
//

/*
 An island is surrounded by water and is formed by connecting adjacent lands horizontally or vertically. You may assume all four edges of the grid are all surrounded by water.
 
 
 
 Example 1:
 
 Input: grid = [
 ["1","1","1","1","0"],
 ["1","1","0","1","0"],
 ["1","1","0","0","0"],
 ["0","0","0","0","0"]
 ]
 
 Output: 1
 // 上下左右连接在一起的 1 是一个整体的岛屿
 
 Example 2:
 
 Input: grid = [
 ["1","1","0","0","0"],
 ["1","1","0","0","0"],
 ["0","0","1","0","0"],
 ["0","0","0","1","1"]
 ]
 Output: 3
 // 上下左右连接在一起的 1 是一个整体的岛屿
 岛屿 1: 01 02 10 11
 岛屿 2: 12
 岛屿 2: 33 34
 
 
 */
private func numIslands(_ grid: [[Character]]) -> Int {
    if grid.count == 0 {return 0}
    var ans = 0, m = grid.count, n = grid[0].count,grid = grid
    let direction = [1,0,-1,0,0]
    
    
    for i in 0 ..< m{
        for j in 0 ..< n{
            if grid[i][j] == "1" {
                ans += 1
                dsfIsland(&grid, i, j, m, n , direction)
            }
        }
    }
    
    
    return ans
    
}

private func dsfIsland(_ grid: inout [[Character]], _ x:Int, _ y:Int , _ m:Int, _ n:Int, _ direction:[Int]) {
    
    if (x < 0 || y < 0 || x >= m || y >= n || grid[x][y] == "0"){
        return
    }
    grid[x][y] = "0"
    let direction = [0,1,0,-1,0]
    
    for i in 0 ..< 4 {
        let tx = direction[i]+x, ty = direction[i+1]+y
        dsfIsland(&grid, tx, ty, m, n, direction)
    }
    
    
    
}
