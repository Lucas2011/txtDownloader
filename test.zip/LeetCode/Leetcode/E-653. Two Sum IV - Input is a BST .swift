/*
 Given the root of a Binary Search Tree and a target number k, return true if there exist two elements in the BST such that their sum is equal to the given target.
 
 
 
 Example 1:
 
 
 Input: root = [5,3,6,2,4,null,7], k = 9
 Output: true
 Example 2:
 
 
 Input: root = [5,3,6,2,4,null,7], k = 28
 Output: false
 */


private func findTarget(_ root: TreeNode?, _ k: Int) -> Bool {
    if root == nil {return false}
    
    var queue = [TreeNode]()
    var dict = [Int:Int]()
    queue.append(root!)
    var size = queue.count
    
    
    while size > 0 {
        let curr = queue.removeFirst()
        let newK = k - curr.val
        if dict[curr.val] != nil {return true}
        if dict[newK] == nil {
            dict[newK] = 1
        }
        if let left = curr.left{
            queue.append(left)
        }
        if let right = curr.right{
            queue.append(right)
        }
        size = queue.count
        
        
    }

    return false
}
