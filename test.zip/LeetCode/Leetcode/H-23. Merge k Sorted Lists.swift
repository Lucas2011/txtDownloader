/*
 You are given an array of k linked-lists lists, each linked-list is sorted in ascending order.

 Merge all the linked-lists into one sorted linked-list and return it.

  

 Example 1:

 Input: lists = [[1,4,5],[1,3,4],[2,6]]
 Output: [1,1,2,3,4,4,5,6]
 Explanation: The linked-lists are:
 [
   1->4->5,
   1->3->4,
   2->6
 ]
 merging them into one sorted list:
 1->1->2->3->4->4->5->6
 Example 2:

 Input: lists = []
 Output: []
 Example 3:

 Input: lists = [[]]
 Output: []

 */
/*
 遍历 [ListNode?] 将所有值存到字典 node.value 作为 key
 创建新 node 然后遍历 dict soredKeys
 */
private func mergeKLists(_ lists: [ListNode?]) -> ListNode? {
    if lists.count == 0 {return nil}
    var node = ListNode(),result = node
    
    var dict = [Int:Int]()
    
    for i in lists{
        addNodeValueToDict(node: i, dict: &dict)
    }
    
    let sortedKey = dict.keys.sorted()
            
    for i in 0 ..< sortedKey.count{
        
        var count = dict[sortedKey[i]] ?? 0
        
        while count != 0 {
            count -= 1
            node.val = sortedKey[i]
            if i == sortedKey.count - 1 && count == 0 {
                continue
            }
            node.next = ListNode()
            node = node.next!
        }
        
    }
    
    
    
    return result
}

private func addNodeValueToDict(node:ListNode? , dict: inout [Int:Int]){
    if node == nil {return}
    var node = node
    while node != nil {
        let value = node!.val
        dict[value] =  dict[value] == nil ? 1 :  dict[value]! + 1
        node = node?.next
    }
    
}
