/*
 Given an integer array nums of unique elements, return all possible subsets (the power set).
 
 The solution set must not contain duplicate subsets. Return the solution in any order.
 
 
 
 Example 1:
 
 Input: nums = [1,2,3]
 Output: [[],[1],[2],[1,2],[3],[1,3],[2,3],[1,2,3]]
 Example 2:
 
 Input: nums = [0]
 Output: [[],[0]]
 */

/*
 数组的所有组合
 */


private func subsets(_ nums: [Int]) -> [[Int]] {
    
    var res = [[Int]]()
    var subset = [Int]()
    
    backtracking(nums: nums, res: &res, subset: &subset, index: 0)
    return res
}

private func backtracking(nums:[Int], res: inout [[Int]], subset:inout [Int], index:Int){
    res.append(subset)
    
    for i in index ..< nums.count{
        subset.append(nums[i])
        backtracking(nums: nums, res: &res, subset: &subset, index: i + 1)
        subset.removeLast()
    }
}
