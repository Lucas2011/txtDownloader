/*
 Given an array of integers nums and an integer k, return the total number of subarrays whose sum equals to k.
 
 
 
 Example 1:
 
 Input: nums = [1,1,1], k = 2
 Output: 2
 Example 2:
 
 Input: nums = [1,2,3], k = 3
 Output: 2
 
 */

private func subarraySum(_ nums: [Int], _ k: Int) -> Int {
    var dict = [Int:Int]()
    dict[0] = 1
    var preSum = 0
    var result = 0
    for i in 0 ..< nums.count{
        preSum += nums[i]
        result += dict[preSum - k] == nil ? 0 : dict[preSum - k]!
        dict[preSum] = dict[preSum] == nil ? 1 : dict[preSum]! + 1
        
    }
    
    return result
    
}
