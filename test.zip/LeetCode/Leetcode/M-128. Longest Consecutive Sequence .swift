/*
 128. Longest Consecutive Sequence
 Medium

 9078

 399

 Add to List

 Share
 Given an unsorted array of integers nums, return the length of the longest consecutive elements sequence.

 You must write an algorithm that runs in O(n) time.

  

 Example 1:

 Input: nums = [100,4,200,1,3,2]
 Output: 4
 Explanation: The longest consecutive elements sequence is [1, 2, 3, 4]. Therefore its length is 4.
 Example 2:

 Input: nums = [0,3,7,2,5,8,4,6,0,1]
 Output: 9
 */

private func longestConsecutive(_ nums: [Int]) -> Int {
       var ans = 0
         var set = Set<Int>()
         for num in nums
         {
             set.insert(num)
         }
         for i in 0 ..< nums.count
         {
             if(!set.contains(nums[i] - 1))
             {
                 var j = nums[i]
                 while (set.contains(j))
                 {
                     j += 1
                 }
                 if(ans < (j - nums[i]))
                 {
                     ans = j - nums[i]
                 }
             }
         }
         return ans
 }
