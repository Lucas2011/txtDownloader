//
//  ViewController.swift
//  Leetcode
//
//  Created by Lucas on 3/14/22.
//

import Cocoa

struct LogsInput {
    var pid:Int
    var isStart: Bool = true
    var time:Int
    init(input:String) {
        let array = input.components(separatedBy: ":")
        self.pid = Int(array[0])!
        self.isStart = array[1] == "start" ? true : false
        self.time = Int(array[2])!
    }
}

struct Cell {
    var node:Int
    var time:Int
    init(node: Int, time: Int) {
        self.node = node
        self.time = time
    }
    
    func compareTo(c2:Cell){
        self.time - c2.time
    }
}

class ViewController: NSViewController {
    
    override func viewDidLoad() {
        super.viewDidLoad()
        //        let treeNode = TreeNode(5)
        //
        //        treeNode.left = TreeNode(2)
        //        treeNode.left?.right = TreeNode(5)
        //        treeNode.left?.left = TreeNode(4)
        //
        //
        //
        //
        //        treeNode.right = TreeNode(3)
        //        treeNode.right?.right = TreeNode(6)
        //        treeNode.right?.right?.left = TreeNode(7)
        //        let tree = createBinaryTree([[4,-7,-3,nil,nil,-9,-3,9,-7,-4,nil,6,nil,-6,-6,nil,nil,0,6,5,nil,9,nil,nil,-1,-4,nil,nil,nil,-2]])
        let tree1 = buildTree([4,-7,-3,nil,nil,-9,-3,9,-7,-4,nil,6,nil,-6,-6,nil,nil,0,6,5,nil,9,nil,nil,-1,-4,nil,nil,nil,-2])
        //
        //        let treeNode2 = Node(15)
        //
        //        treeNode.left = Node(2)
        //        treeNode.left?.left = Node(4)
        //        treeNode.left?.right = Node(5)
        //
        //        treeNode.right = Node(3)
        //        //        treeNode.right?.left = Node(15)
        //        treeNode.right?.right = Node(7)
        
        /*
         [
         [0,0,0],
         [1,1,0],
         [1,1,1]
         */
        
        
        
        
        
        
        print(
//            diameterOfBinaryTree(tree1)
        )
        
        let tree2 = buildTree([5,4,8,11,nil,13,4,7,2,nil,nil,nil,1])

        func hasPathSum(_ root: TreeNode?, _ targetSum: Int) -> Bool {
            return dfs(root, 0, targetSum)
        }

        func dfs(_ node: TreeNode?, _ currentSum: Int, _ targetSum: Int) -> Bool {
            guard let node = node else { return false }
            
            // Update the current sum with the current node's value
            let newCurrentSum = currentSum + node.val
            
            // Check if it's a leaf node and if the current sum equals the target sum
            if node.left == nil && node.right == nil {
                return newCurrentSum == targetSum
            }
            
            // Recursively check the left and right subtrees
            return dfs(node.left, newCurrentSum, targetSum) || dfs(node.right, newCurrentSum, targetSum)
        }

        
        print(hasPathSum(tree2, 22))
        
//        print(letterCombinations("23"))
        
       
        
        
        
        func letterCombinations(_ digits: String) -> [String] {
            guard !digits.isEmpty else { return [] }
            let keyBoard = [
                "0": "",
                "1": "",
                "2": "abc",
                "3": "def",
                "4": "ghi",
                "5": "jkl",
                "6": "mno",
                "7": "pqrs",
                "8": "tuv",
                "9": "wxyz"
            ]
            
            
            var stringBuild = [String]()
            var result = [String]()
            
            dfs(digits: digits, index: 0, stringBuilder: &stringBuild, result: &result,keyboard:keyBoard)
            
            return result
        }
        
        
        func dfs (digits:String, index:Int, stringBuilder:inout [String], result:inout [String], keyboard:[String:String]) {
            
            if index == digits.count {
                result.append(stringBuilder.joined())
                return
            }
            
            let digit = String(digits[digits.index(digits.startIndex, offsetBy: index)])
            let letters = keyboard[digit]!

            print("result: \(result)")

            for char in letters {
                stringBuilder.append(String(char))
                print("stringBuilder: \(stringBuilder)")
                dfs(digits: digits, index: index + 1, stringBuilder: &stringBuilder, result: &result, keyboard:keyboard)
                stringBuilder.removeLast()  // Corrected to ensure we're modifying the right array
            }
            
        }
        
        
   
        
        func diameterOfBinaryTree(_ root: TreeNode?) -> Int {
            if root == nil {return 0}
            let leftCount = dsf(root?.left)
            let rightCount = dsf(root?.right)
            return leftCount + rightCount
        }
        
        
        func dsf(_ root: TreeNode?) -> Int {
            guard let root = root else {return 0}
            let leftSum = dsf(root.left)
            let rightSum = dsf(root.right)
            return max(leftSum, rightSum) + 1
        }
        
        
        
        
        
        
        func buildTree(_ array: [Int?]) -> TreeNode? {
            guard !array.isEmpty else {
                return nil
            }
            
            // 用于构建树的辅助函数
            func buildNode(_ index: Int) -> TreeNode? {
                guard index < array.count, let value = array[index] else {
                    return nil
                }
                
                let node = TreeNode(value)
                node.left = buildNode(2 * index + 1)
                node.right = buildNode(2 * index + 2)
                
                return node
            }
            
            return buildNode(0)
        }
        
        
        
        
        
        
        
        
    }
}























