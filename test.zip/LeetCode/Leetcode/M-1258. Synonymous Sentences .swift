/*
 You are given a list of equivalent string pairs synonyms where synonyms[i] = [si, ti] indicates that si and ti are equivalent strings. You are also given a sentence text.
 
 Return all possible synonymous sentences sorted lexicographically.
 
 
 
 Example 1:
 
 Input: synonyms = [["happy","joy"],["sad","sorrow"],["joy","cheerful"]], text = "I am happy today but was sad yesterday"
 Output: ["I am cheerful today but was sad yesterday","I am cheerful today but was sorrow yesterday","I am happy today but was sad yesterday","I am happy today but was sorrow yesterday","I am joy today but was sad yesterday","I am joy today but was sorrow yesterday"]
 Example 2:
 
 Input: synonyms = [["happy","joy"],["cheerful","glad"]], text = "I am happy today but was sad yesterday"
 Output: ["I am happy today but was sad yesterday","I am joy today but was sad yesterday"]
 */

func generateSentences(_ synonyms: [[String]], _ text: String) -> [String] {
    var map = [String: [String]]()
    for synonym in synonyms {
        map[synonym[0], default: [String]()].append(synonym[1])
        map[synonym[1], default: [String]()].append(synonym[0])
    }
    var res = [String]()
    let arr = text.split(separator: " ").map({String($0)})
    dfs(arr, &res, 0, map, "")
    return res.sorted(by: <)
}

func dfs(_ arr: [String], _ res: inout [String], _ index: Int, _ map: [String: [String]], _ temp: String) {
    if index == arr.count {
        res.append(temp)
        return
    }
    
    let str = arr[index]
    
    for equal in getAllNeigh(str, map) {
        var cur = temp + equal
        if index != arr.count - 1 {
            cur += " "
        }
        dfs(arr, &res, index+1, map, cur)
    }
}

func getAllNeigh(_ str: String, _ map: [String: [String]]) -> [String] {
    var queue = [String]()
    var res = [String]()
    var set = Set<String>()
    queue.append(str)
    
    while queue.count > 0 {
        let cur = queue.removeFirst()
        res.append(cur)
        set.insert(cur)
        if let arr = map[cur] {
            
            for neigh in arr {
                if !set.contains(neigh) {
                    queue.append(neigh)
                }
            }
        }
    }
    return res
}
