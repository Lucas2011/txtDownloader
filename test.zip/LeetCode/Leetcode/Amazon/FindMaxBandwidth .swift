//
//  FindMaxBandwidth .swift
//  Leetcode
//
//  Created by Lucas on 5/29/22.
//

import Foundation
/*
 Find Max Bandwidth
 For n tv channels, given show start time, end time & bandwidth needed for each channels, find the maximum bandwidth required at peak. a show represented as [1,30,2] meaning [show-start-time, show-end-time, bandwidth-needed].
 
 e.g. n =3 channels,
 
 [[1,30, 2],[31,60, 4],[61,120, 3],
 [1,20,2],[21,40,4],[41,60,5],[61,120,3],
 [1,60,4],[61,120,4]]
 
 Ans: 13, for time slot between 41-60 each channel need 4,5,4 bandwidth respectively. 13 is highest (peek/max) bandwidth.
 
 Note
 
 Min-size-of-show = 2 (min)
 Max-duration-for-show = 720 (min) same as 24hours
 Max-bandwidth-per-show = 100 (mbps)
 n<1000
 Some channels can decide not to broadcast any show for given time-slot, which mean there will be 0 bandwidth required for that channel for given time-slot.
 private
 */



/*
[[1,30, 2],[31,60, 4],[61,120, 3],
[1,20,2],[21,40,4],[41,60,5],[61,120,3],
[1,60,4],[61,120,4]]
 */
 
private func get_max_bandwidth(bandwidths:[[Int]]) -> Int{
    var points = [[Int]]()
    for ch in bandwidths {
        points.append([ch[0],ch[2]]) //[ [1,2], [30,-2] ]
        points.append([ch[1],ch[2] * -1])
        
    }
    
    
    points = points.sorted(by: {$0[0] < $1[0] })
    var max_value = 0
    var curr_value = 0
    for band in points {
        curr_value += band.last ?? 0
        max_value = max (curr_value, max_value)
    }
    return max_value
}

/*
step 1) First we need to create a timeline in the system. The timeline will be composed of two type of events - positive bandwidth (at start of interval) and negative bandwidth (at end of interval).
Each point on the time line will look like (time, bandwitdh). For instance, you can break (1, 10, 2) as two intervals - (1, 2) & (10, -2)

step 2) sort the points based on the time component.

step3) keep the count of the sum as you iterate through points. The max sum will give you the max bandwidth requirement.
*/
