//
//  ViewController.h
//  coredatademo
//
//  Created by Lucas on 2/8/25.
//

#import <Cocoa/Cocoa.h>

@interface ViewController : NSViewController


@end

