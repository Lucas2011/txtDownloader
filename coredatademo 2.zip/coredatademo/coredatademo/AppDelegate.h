//
//  AppDelegate.h
//  coredatademo
//
//  Created by Lucas on 2/8/25.
//

#import <Cocoa/Cocoa.h>

@interface AppDelegate : NSObject <NSApplicationDelegate>


@end

