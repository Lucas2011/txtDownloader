//
//  testCoredataManager.m
//  coredatademo
//
//  Created by Lucas on 2/8/25.
//

#import "testCoredataManager.h"
#import <CoreData/CoreData.h>

// Core Data Manager 的主要实现类
// Main implementation class for Core Data Manager
@interface testCoredataManager ()

// 主要的托管对象上下文,用于主线程操作
// Main managed object context for main thread operations
@property (nonatomic, strong, readwrite) NSManagedObjectContext *managedObjectContext;

// 持久化存储协调器,负责管理数据存储
// Persistent store coordinator responsible for managing data storage
@property (nonatomic, strong, readwrite) NSPersistentStoreCoordinator *persistentStoreCoordinator;

// 数据模型对象,定义了实体和关系
// Data model object that defines entities and relationships
@property (nonatomic, strong) NSManagedObjectModel *managedObjectModel;

// 用于后台操作的串行队列
// Serial queue for background operations
@property (nonatomic, strong) dispatch_queue_t operationQueue;

// 用于序列化访问的串行队列
// Serial queue for serialized access
@property (nonatomic, strong) dispatch_queue_t serialQueue;

// 用于版本控制的原子计数器
// Atomic counter for version control
@property (atomic, assign) NSUInteger updateVersion;

// 用于同步访问的锁对象
// Lock object for synchronized access
@property (nonatomic, strong) NSLock *updateLock;

// Private method declarations
- (void)executeUpdateWithRequest:(NSFetchRequest *)request
                     inContext:(NSManagedObjectContext *)context
                   updateBlock:(void(^)(Person *person, NSMutableDictionary *data))updateBlock
                   completion:(void(^)(BOOL success))completion;
@end

@implementation testCoredataManager

#pragma mark - Singleton & Init

/**
 * Core Data 管理器的单例方法
 * Singleton method for Core Data manager
 *
 * 确保整个应用程序只有一个Core Data管理器实例，统一管理数据操作
 * Ensures only one Core Data manager instance exists throughout the application
 *
 * @return 返回Core Data管理器的共享实例
 * @return Returns the shared instance of Core Data manager
 */
+ (instancetype)sharedManager {
    static testCoredataManager *sharedManager = nil;
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        sharedManager = [[self alloc] init];
    });
    return sharedManager;
}

/**
 * 初始化方法
 * Initialization method
 *
 * 设置Core Data栈和必要的操作队列
 * Sets up Core Data stack and necessary operation queues
 *
 * @return 返回初始化后的实例
 * @return Returns the initialized instance
 */
- (instancetype)init {
    self = [super init];
    if (self) {
        [self setupCoreData];
        // 创建两个串行队列用于不同目的
        // Create two serial queues for different purposes
        self.operationQueue = dispatch_queue_create("com.app.coredata.operation", DISPATCH_QUEUE_SERIAL);
        self.serialQueue = dispatch_queue_create("com.app.coredata.serial", DISPATCH_QUEUE_SERIAL);
        self.updateLock = [[NSLock alloc] init];
        self.updateVersion = 0;
    }
    return self;
}

#pragma mark - Core Data Setup

/**
 * 设置Core Data栈
 * Setup Core Data stack
 *
 * 初始化Core Data所需的所有组件,包括模型、协调器和上下文
 * Initializes all components needed for Core Data, including model, coordinator and context
 */
- (void)setupCoreData {
    // 加载数据模型文件
    // Load data model file
    NSURL *modelURL = [[NSBundle mainBundle] URLForResource:@"Mod" withExtension:@"momd"];
    self.managedObjectModel = [[NSManagedObjectModel alloc] initWithContentsOfURL:modelURL];
    
    // 创建持久化存储协调器
    // Create persistent store coordinator
    self.persistentStoreCoordinator = [[NSPersistentStoreCoordinator alloc] initWithManagedObjectModel:self.managedObjectModel];
    
    // 设置 SQLite 存储文件路径
    // Setup SQLite store file path
    NSURL *storeURL = [[self applicationDocumentsDirectory] URLByAppendingPathComponent:@"CoreDataDemo.sqlite"];
    
    // 添加持久化存储
    // Add persistent store
    NSError *error = nil;
    if (![self.persistentStoreCoordinator addPersistentStoreWithType:NSSQLiteStoreType
                                                      configuration:nil
                                                                URL:storeURL
                                                            options:nil
                                                              error:&error]) {
        NSLog(@"Core Data setup error: %@", error);
    }
    
    // 创建主队列上下文
    // Create main queue context
    self.managedObjectContext = [[NSManagedObjectContext alloc] initWithConcurrencyType:NSMainQueueConcurrencyType];
    self.managedObjectContext.persistentStoreCoordinator = self.persistentStoreCoordinator;
}

#pragma mark - Utilities

/**
 * 获取应用程序文档目录
 * Get application documents directory
 *
 * @return 返回文档目录的URL
 * @return Returns URL of documents directory
 */
- (NSURL *)applicationDocumentsDirectory {
    return [[[NSFileManager defaultManager] URLsForDirectory:NSDocumentDirectory 
                                                 inDomains:NSUserDomainMask] lastObject];
}

/**
 * 创建新的私有上下文
 * Create new private context
 *
 * 创建一个用于后台操作的私有托管对象上下文
 * Creates a private managed object context for background operations
 *
 * @return 返回新创建的私有上下文
 * @return Returns newly created private context
 */
- (NSManagedObjectContext *)newPrivateContext {
    NSManagedObjectContext *privateContext = [[NSManagedObjectContext alloc] initWithConcurrencyType:NSPrivateQueueConcurrencyType];
    privateContext.persistentStoreCoordinator = self.persistentStoreCoordinator;
    return privateContext;
}

#pragma mark - CRUD Operations

/**
 * 同步获取所有Person对象
 * Synchronously fetch all Person objects
 *
 * 在后台上下文执行查询,并在主上下文返回结果
 * Executes query in background context and returns results in main context
 *
 * @return 返回所有Person对象的数组
 * @return Returns array of all Person objects
 */
- (NSArray<Person *> *)fetchAllPersons {
    NSManagedObjectContext *privateContext = [[NSManagedObjectContext alloc] initWithConcurrencyType:NSPrivateQueueConcurrencyType];
    privateContext.persistentStoreCoordinator = self.persistentStoreCoordinator;
    
    __block NSArray<NSManagedObjectID *> *objectIDs = nil;
    [privateContext performBlockAndWait:^{
        @try {
            NSFetchRequest *request = [Person fetchRequest];
            request.returnsObjectsAsFaults = NO;
            
            NSError *error = nil;
            NSArray *fetchedResults = [privateContext executeFetchRequest:request error:&error];
            
            if (error) {
                NSLog(@"Fetch error: %@", error);
                objectIDs = @[];
                return;
            }
            
            // Get object IDs instead of objects
            objectIDs = [fetchedResults valueForKey:@"objectID"];
            
        } @catch (NSException *exception) {
            NSLog(@"Fetch exception: %@", exception);
            objectIDs = @[];
        }
    }];
    
    // Convert to managed objects in main context
    NSMutableArray *managedObjects = [NSMutableArray array];
    for (NSManagedObjectID *objectID in objectIDs) {
        NSManagedObject *obj = [self.managedObjectContext objectWithID:objectID];
        if (obj) {
            [managedObjects addObject:obj];
        }
    }
    
    return [managedObjects copy];
}

/**
 * 同步更新Person对象
 * Synchronously update Person object
 *
 * 在私有上下文中更新指定的Person对象
 * Updates specified Person object in private context
 *
 * @param person 要更新的Person对象
 * @param person The Person object to update
 * @return 返回更新是否成功
 * @return Returns whether update was successful
 */
- (BOOL)updatePerson:(Person *)person {
    if (!person || !person.objectID) return NO;
    
    NSManagedObjectContext *privateContext = [[NSManagedObjectContext alloc] initWithConcurrencyType:NSPrivateQueueConcurrencyType];
    privateContext.persistentStoreCoordinator = self.persistentStoreCoordinator;
    
    __block BOOL success = NO;
    [privateContext performBlockAndWait:^{
        @try {
            Person *privatePerson = (Person *)[privateContext objectWithID:person.objectID];
            if (!privatePerson) return;
            
            // 复制属性
            privatePerson.name = person.name;
            
            NSError *error = nil;
            success = [privateContext save:&error];
            
            if (success) {
                [self.managedObjectContext performBlockAndWait:^{
                    NSError *mainError = nil;
                    if (![self.managedObjectContext save:&mainError]) {
                        success = NO;
                    }
                }];
            }
        } @catch (NSException *exception) {
            NSLog(@"Update exception: %@", exception);
            success = NO;
        }
    }];
    
    return success;
}

/**
 * 同步删除Person对象
 * Synchronously delete Person object
 *
 * 在私有上下文中删除指定的Person对象
 * Deletes specified Person object in private context
 *
 * @param person 要删除的Person对象
 * @param person The Person object to delete
 * @return 返回删除是否成功
 * @return Returns whether deletion was successful
 */
- (BOOL)deletePerson:(Person *)person {
    if (!person || !person.objectID) return NO;
    
    NSManagedObjectContext *privateContext = [[NSManagedObjectContext alloc] initWithConcurrencyType:NSPrivateQueueConcurrencyType];
    privateContext.persistentStoreCoordinator = self.persistentStoreCoordinator;
    
    __block BOOL success = NO;
    [privateContext performBlockAndWait:^{
        @try {
            Person *privatePerson = (Person *)[privateContext objectWithID:person.objectID];
            if (!privatePerson) return;
            
            [privateContext deleteObject:privatePerson];
            
            NSError *error = nil;
            success = [privateContext save:&error];
            
            if (success) {
                [self.managedObjectContext performBlockAndWait:^{
                    NSError *mainError = nil;
                    if (![self.managedObjectContext save:&mainError]) {
                        success = NO;
                    }
                }];
            }
        } @catch (NSException *exception) {
            NSLog(@"Delete exception: %@", exception);
            success = NO;
        }
    }];
    
    return success;
}

/**
 * 获取按日期排序的Person对象
 * Get Person objects sorted by date
 *
 * 获取所有Person对象并按创建日期排序
 * Fetches all Person objects and sorts them by creation date
 *
 * @param ascending 是否升序排列
 * @param ascending Whether to sort in ascending order
 * @return 返回排序后的Person对象数组
 * @return Returns sorted array of Person objects
 */
- (NSArray<Person *> *)fetchAllPersonsSortedByDate:(BOOL)ascending {
    NSManagedObjectContext *privateContext = [[NSManagedObjectContext alloc] initWithConcurrencyType:NSPrivateQueueConcurrencyType];
    privateContext.persistentStoreCoordinator = self.persistentStoreCoordinator;
    
    NSFetchRequest *request = [Person fetchRequest];
    
    // 添加排序描述符
    NSSortDescriptor *sortDescriptor = [NSSortDescriptor sortDescriptorWithKey:@"createDate" 
                                                                   ascending:ascending];
    request.sortDescriptors = @[sortDescriptor];
    
    __block NSArray<Person *> *results = nil;
    [privateContext performBlockAndWait:^{
        @try {
            NSError *error = nil;
            NSArray *fetchedResults = [privateContext executeFetchRequest:request error:&error];
            
            if (error) {
                NSLog(@"Fetch error: %@", error);
                results = @[];
                return;
            }
            
            // 创建不可变副本
            results = [[NSArray alloc] initWithArray:fetchedResults copyItems:NO];
            
        } @catch (NSException *exception) {
            NSLog(@"Fetch exception: %@", exception);
            results = @[];
        }
    }];
    
    return results ?: @[];
}

/**
 * 安全地异步获取所有 Person 对象的方法
 * 该方法在后台线程执行查询操作，并在主线程返回结果
 *
 * @param completion 完成回调block，在主线程中调用，返回查询结果
 */
- (void)fetchAllPersonsWithCompletion:(void(^)(NSArray<Person *> *persons))completion {
    // 验证回调block是否存在，确保安全调用
    if (!completion) return;
    
    // 1. 使用串行队列确保数据操作的顺序性
    // 防止多个操作同时执行导致的数据竞争
    dispatch_async(self.serialQueue, ^{
        // 2. 创建私有上下文
        // 使用 NSPrivateQueueConcurrencyType 类型，确保在独立队列中执行
        // 避免阻塞主线程，提高应用响应性
        NSManagedObjectContext *privateContext = [[NSManagedObjectContext alloc] 
            initWithConcurrencyType:NSPrivateQueueConcurrencyType];
        privateContext.persistentStoreCoordinator = self.persistentStoreCoordinator;
        
        // 3. 在私有上下文的队列中执行查询操作
        // performBlock 确保在正确的队列中执行数据操作
        [privateContext performBlock:^{
            // 创建获取请求
            NSFetchRequest *request = [Person fetchRequest];
            // 禁用 faults 优化内存使用，直接加载完整对象
            request.returnsObjectsAsFaults = NO;
            
            NSError *error = nil;
            // 执行查询
            NSArray *results = [privateContext executeFetchRequest:request error:&error];
            
            // 4. 获取对象ID而不是直接传递托管对象
            // objectID 是线程安全的，可以在不同线程间传递
            // 避免了跨线程访问 NSManagedObject 的问题
            NSArray *objectIDs = [results valueForKey:@"objectID"];
            
            // 5. 切换到主线程，使用主上下文重新获取对象
            dispatch_async(dispatch_get_main_queue(), ^{
                // 6. 在主上下文中重新构建对象数组
                // 确保返回的对象可以安全地在主线程使用
                NSMutableArray *managedObjects = [NSMutableArray array];
                for (NSManagedObjectID *objectID in objectIDs) {
                    // 使用 objectID 在主上下文中获取对象
                    // 这样获取的对象绑定到主上下文，可以安全地用于UI操作
                    NSManagedObject *obj = [self.managedObjectContext objectWithID:objectID];
                    if (obj) {
                        [managedObjects addObject:obj];
                    }
                }
                
                // 7. 在主线程中回调，返回结果
                // 确保UI操作在主线程执行，避免线程问题
                completion(managedObjects);
            });
        }];
    });
}

/**
 * 异步删除Person对象
 * Asynchronously delete Person object
 *
 * 在后台线程中安全地删除指定的Person对象，并在主线程返回结果
 * Safely deletes the specified Person object in background thread and returns result on main thread
 *
 * @param person 要删除的Person对象
 * @param person The Person object to delete
 * @param completion 完成回调，在主线程中调用，返回操作是否成功
 * @param completion Completion handler called on main thread with operation success status
 */
- (void)deletePerson:(Person *)person completion:(void(^)(BOOL success))completion {
    if (!person || !person.objectID) {
        if (completion) {
            dispatch_async(dispatch_get_main_queue(), ^{
                completion(NO);
            });
        }
        return;
    }
    
    NSManagedObjectContext *privateContext = [[NSManagedObjectContext alloc] initWithConcurrencyType:NSPrivateQueueConcurrencyType];
    privateContext.persistentStoreCoordinator = self.persistentStoreCoordinator;
    
    [privateContext performBlock:^{
        __block BOOL success = NO;
        @try {
            Person *privatePerson = (Person *)[privateContext objectWithID:person.objectID];
            if (!privatePerson) {
                if (completion) {
                    dispatch_async(dispatch_get_main_queue(), ^{
                        completion(NO);
                    });
                }
                return;
            }
            
            [privateContext deleteObject:privatePerson];
            
            NSError *error = nil;
            success = [privateContext save:&error];
            
            if (success) {
                [self.managedObjectContext performBlockAndWait:^{
                    NSError *mainError = nil;
                    if (![self.managedObjectContext save:&mainError]) {
                        success = NO;
                    }
                }];
            }
        } @catch (NSException *exception) {
            NSLog(@"Async delete exception: %@", exception);
            success = NO;
        }
        
        if (completion) {
            dispatch_async(dispatch_get_main_queue(), ^{
                completion(success);
            });
        }
    }];
}


#pragma mark - Helper Methods

/**
 * 在指定上下文中更新Person对象
 * Update Person objects in the specified context
 *
 * 批量更新Person对象，支持自定义更新逻辑
 * Batch updates Person objects with custom update logic
 *
 * @param persons 要更新的Person对象数组
 * @param persons Array of Person objects to update
 * @param context 执行更新操作的上下文
 * @param context The context in which to perform updates
 * @param updateBlock 自定义更新逻辑的block
 * @param updateBlock Block containing custom update logic
 */
- (void)updatePersons:(NSArray *)persons 
           inContext:(NSManagedObjectContext *)context 
         updateBlock:(void(^)(Person *, NSMutableDictionary *))updateBlock {
    for (Person *person in persons) {
        // Get object in private context
        Person *privatePerson = (Person *)[context objectWithID:person.objectID];
        
        // Prepare mutable dictionary
        NSMutableDictionary *mutableData = [self mutableDataFromPerson:privatePerson];
        
        // Execute update
        if (updateBlock) {
            updateBlock(privatePerson, mutableData);
        }
        
        // Save updated data
        privatePerson.data = [mutableData copy];
    }
}

/**
 * 从Person对象创建可变字典
 * Create mutable dictionary from Person object
 *
 * 将Person对象的data属性转换为可变字典
 * Converts data property of Person object to mutable dictionary
 *
 * @param person Person对象
 * @param person Person object
 * @return 返回可变字典
 * @return Returns mutable dictionary
 */
- (NSMutableDictionary *)mutableDataFromPerson:(Person *)person {
    if ([person.data isKindOfClass:[NSDictionary class]]) {
        return [(NSDictionary *)person.data mutableCopy];
    }
    return [NSMutableDictionary dictionary];
}

/**
 * 保存上下文
 * Save context
 *
 * 保存指定的托管对象上下文
 * Saves the specified managed object context
 *
 * @param context 要保存的上下文
 * @param context The context to save
 * @return 返回保存是否成功
 * @return Returns whether save was successful
 */
- (BOOL)saveContext:(NSManagedObjectContext *)context {
    NSError *error = nil;
    BOOL success = [context save:&error];
    
    if (!success) {
        NSLog(@"Failed to save context: %@", error);
    }
    return success;
}

/**
 * 通知主上下文并完成操作
 * Notify main context and complete operation
 *
 * 重置主上下文并发送数据更新通知
 * Resets main context and posts data update notification
 *
 * @param completion 完成回调
 * @param completion Completion handler
 */
- (void)notifyMainContextAndComplete:(void(^)(BOOL))completion {
    [self.managedObjectContext performBlock:^{
        [self.managedObjectContext reset];
        [[NSNotificationCenter defaultCenter] postNotificationName:@"DataDidUpdateNotification" 
                                                        object:nil];
        [self completeOnMainThread:completion withSuccess:YES];
    }];
}

/**
 * 在主线程执行完成回调
 * Execute completion callback on main thread
 *
 * 确保完成回调在主线程执行
 * Ensures completion handler is executed on main thread
 *
 * @param completion 完成回调
 * @param completion Completion handler
 * @param success 操作是否成功
 * @param success Whether operation was successful
 */
- (void)completeOnMainThread:(void(^)(BOOL))completion withSuccess:(BOOL)success {
    if (completion) {
        dispatch_async(dispatch_get_main_queue(), ^{
            completion(success);
        });
    }
}

- (void)updatePersonsWithPredicate:(NSString *)predicateFormat
                     predicateArgs:(NSDictionary *)args
                     updateBlock:(void(^)(Person *person, NSMutableDictionary *data))updateBlock 
                     completion:(void(^)(BOOL success))completion {
                          // 1. 首先进入串行队列（后台线程）
  
    dispatch_async(self.serialQueue, ^{
                // 2. 创建私有上下文（后台线程）

        NSManagedObjectContext *privateContext = [self newPrivateContext];
        
                // 3. 在私有上下文的队列中执行（后台线程）
        [privateContext performBlock:^{
            @try {
                // Create request with conditions
                NSFetchRequest *request = [Person fetchRequest];
                
                // Build predicate
                NSPredicate *predicate = [NSPredicate predicateWithFormat:predicateFormat 
                                                     argumentArray:@[args]];
                request.predicate = predicate;
                
                // Execute query and update
                [self executeUpdateWithRequest:request
                                  inContext:privateContext
                                updateBlock:updateBlock
                                completion:completion];
                
            } @catch (NSException *exception) {
                                // 6. 最后通过 completeOnMainThread 切换到主线程
                NSLog(@"Batch update failed: %@", exception);
                [self completeOnMainThread:completion withSuccess:NO];
            }
        }];
    });
}

/**
 * 安全地插入Person对象
 * Safely insert Person object
 *
 * 在后台线程中创建并插入新的Person对象
 * Creates and inserts new Person object in background thread
 *
 * @param personData Person对象的数据字典
 * @param personData Dictionary containing Person object data
 * @param completion 完成回调
 * @param completion Completion handler
 */
- (void)insertPersonWithData:(NSDictionary *)personData 
                 completion:(void(^)(BOOL success))completion {
    
    dispatch_async(self.serialQueue, ^{
        // Create private context
        NSManagedObjectContext *privateContext = [self newPrivateContext];
        
        [privateContext performBlock:^{
            @try {
                // Create new Person in private context
                Person *newPerson = [[Person alloc] initWithContext:privateContext];
                
                // Set properties
                newPerson.name = personData[@"name"];
                newPerson.age = [personData[@"age"] integerValue];
                
                // Set dictionary data
                if (personData[@"data"] && [personData[@"data"] isKindOfClass:[NSDictionary class]]) {
                    newPerson.data = [personData[@"data"] copy];
                }
                
                // Set creation date
                
                // Save context
                if ([self saveContext:privateContext]) {
                    // Notify main context to refresh
                    [self notifyMainContextAndComplete:completion];
                } else {
                    [self completeOnMainThread:completion withSuccess:NO];
                }
                
            } @catch (NSException *exception) {
                NSLog(@"Insert failed: %@", exception);
                [self completeOnMainThread:completion withSuccess:NO];
            }
        }];
    });
}

/**
 * 执行更新请求
 * Execute update request
 *
 * 执行批量更新操作
 * Performs batch update operation
 *
 * @param request 获取请求
 * @param request Fetch request
 * @param context 执行上下文
 * @param context Execution context
 * @param updateBlock 更新逻辑
 * @param updateBlock Update logic
 * @param completion 完成回调
 * @param completion Completion handler
 */
- (void)executeUpdateWithRequest:(NSFetchRequest *)request
                     inContext:(NSManagedObjectContext *)context
                   updateBlock:(void(^)(Person *person, NSMutableDictionary *data))updateBlock
                   completion:(void(^)(BOOL success))completion {
    
    NSError *error = nil;
    NSArray *persons = [context executeFetchRequest:request error:&error];
    
    if (error) {
        NSLog(@"Failed to fetch data: %@", error);
        [self completeOnMainThread:completion withSuccess:NO];
        return;
    }
    
    for (Person *person in persons) {
        NSMutableDictionary *mutableData = [person.data mutableCopy];
        if (!mutableData) {
            mutableData = [NSMutableDictionary dictionary];
        }
        
        updateBlock(person, mutableData);
        person.data = [mutableData copy];
    }
    
    // Save changes
    if ([self saveContext:context]) {
        [self notifyMainContextAndComplete:completion];
    } else {
        [self completeOnMainThread:completion withSuccess:NO];
    }
}

@end
