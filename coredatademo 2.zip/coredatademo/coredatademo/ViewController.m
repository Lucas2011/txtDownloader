//
//  ViewController.m
//  coredatademo
//
//  Created by Lucas on 2/8/25.
//

#import "ViewController.h"
#import "testCoredataManager.h"
#import <CoreData/CoreData.h>

@interface ViewController () <NSTableViewDelegate, NSTableViewDataSource>
@property (nonatomic, strong) NSTableView *tableView;
@property (nonatomic, strong) NSArray<Person *> *dataArray;
@property (nonatomic, strong) NSScrollView *scrollView;
@property (atomic, assign) BOOL isUpdating;
@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    // 设置 ScrollView
    self.scrollView = [[NSScrollView alloc] initWithFrame:self.view.bounds];
    self.scrollView.hasVerticalScroller = YES;
    self.scrollView.autoresizingMask = NSViewWidthSizable | NSViewHeightSizable;
    
    // 设置 TableView
    self.tableView = [[NSTableView alloc] initWithFrame:NSZeroRect];
    self.tableView.delegate = self;
    self.tableView.dataSource = self;
    
    // 添加列
    NSTableColumn *dateColumn = [[NSTableColumn alloc] initWithIdentifier:@"DateColumn"];
    dateColumn.title = @"Date";
    dateColumn.width = 200;
    [self.tableView addTableColumn:dateColumn];
    
    // 设置 TableView 到 ScrollView
    self.scrollView.documentView = self.tableView;
    [self.view addSubview:self.scrollView];
    
    [self performSelectorInBackground:@selector(updatePersonsExample) withObject:nil];

    // 设置通知监听数据变化
    [[NSNotificationCenter defaultCenter] addObserver:self
                                           selector:@selector(managedObjectContextDidChange:)
                                               name:NSManagedObjectContextDidSaveNotification
                                             object:nil];
    
    [self loadData];
    
    // 获取所有 Person 对象
    NSArray<Person *> *persons = [[testCoredataManager sharedManager] fetchAllPersons];
    
    // 遍历并修改数据
    for (Person *person in persons) {
        // 直接设置 person 的 name 属性
        person.name = @"new value";
        
        // 保存修改
        [[testCoredataManager sharedManager] updatePerson:person];
    }
    
    [[NSNotificationCenter defaultCenter] addObserver:self 
                                           selector:@selector(handleDataUpdate:) 
                                               name:@"DataDidUpdateNotification" 
                                             object:nil];
    
    self.isUpdating = YES;
    [self startUpdateThreads];
}

- (void)startUpdateThreads {
    dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_BACKGROUND, 0), ^{
        [self updateTheDataInThreadA];
    });
    
    dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_BACKGROUND, 0), ^{
        [self updateTheDataInThreadB];
    });
}

- (void)loadData {
    // 使用新的 fetchAllPersons 方法
    self.dataArray = [[testCoredataManager sharedManager] fetchAllPersons];
    [self.tableView reloadData];
}

// 处理数据变化通知
- (void)managedObjectContextDidChange:(NSNotification *)notification {
    [self.tableView reloadData];
}

- (void)dealloc {
    self.isUpdating = NO;
    [[NSNotificationCenter defaultCenter] removeObserver:self];
}

// 添加比较方法
- (NSComparisonResult)compareDate:(id)otherObject {
    NSDate *date1 = [self valueForKey:@"createDate"];
    NSDate *date2 = [otherObject valueForKey:@"createDate"];
    return [date2 compare:date1]; // 降序排列
    // 如果要升序排列，使用：return [date1 compare:date2];
}

#pragma mark - NSTableViewDataSource

- (NSInteger)numberOfRowsInTableView:(NSTableView *)tableView {
    return self.dataArray.count;
}

#pragma mark - NSTableViewDelegate

- (NSView *)tableView:(NSTableView *)tableView viewForTableColumn:(NSTableColumn *)tableColumn row:(NSInteger)row {
    NSString *identifier = tableColumn.identifier;
    NSTableCellView *cellView = [tableView makeViewWithIdentifier:identifier owner:self];
    
    if (!cellView) {
        cellView = [[NSTableCellView alloc] init];
        cellView.identifier = identifier;
        
        NSTextField *textField = [[NSTextField alloc] init];
        textField.bezeled = NO;
        textField.drawsBackground = NO;
        textField.editable = NO;
        textField.selectable = YES;
        cellView.textField = textField;
        [cellView addSubview:textField];
    }
    
    // 获取数据
    NSManagedObject *item = self.dataArray[row];
    NSDate *date = [item valueForKey:@"createDate"];
    
    // 设置日期格式
    NSDateFormatter *formatter = [[NSDateFormatter alloc] init];
    formatter.dateFormat = @"yyyy-MM-dd HH:mm:ss";
    
    cellView.textField.stringValue = [formatter stringFromDate:date];
    
    return cellView;
}

- (void)setRepresentedObject:(id)representedObject {
    [super setRepresentedObject:representedObject];

    // Update the view, if already loaded.
}


- (void)loadSortedData {
    // 在后台队列执行数据获取
    dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0), ^{
        NSArray *sortedPersons = [[testCoredataManager sharedManager] fetchAllPersonsSortedByDate:NO];
        
        // 在主队列更新 UI
        dispatch_async(dispatch_get_main_queue(), ^{
            self.dataArray = sortedPersons;
            [self.tableView reloadData];
        });
    });
}




- (void)handleDataUpdate:(NSNotification *)notification {
    dispatch_async(dispatch_get_main_queue(), ^{
        [self loadData];
    });
    
 
}





- (void)insertNewPerson {
    // 准备插入数据
    NSDictionary *personData = @{
        @"name": @"John Doe",
        @"age": @25,
        @"data": @{
            @"email": @"john@example.com",
            @"phone": @"123-456-7890",
            @"address": @{
                @"city": @"New York",
                @"country": @"USA"
            }
        }
    };
    
    // 执行插入
    [[testCoredataManager sharedManager] insertPersonWithData:personData completion:^(BOOL success) {
        if (success) {
            // 插入成功，刷新UI
            [self loadData];
        } else {
            // 处理错误
            NSLog(@"Failed to insert person");
        }
    }];
}


- (void)updateTheDataInThreadB {
    while (true) {
        @autoreleasepool {
            dispatch_semaphore_t semaphore = dispatch_semaphore_create(0);
            
//            NSString *predicateFormat = @"name CONTAINS[c] %@ AND age < %@";
//                     NSDictionary *args = @{
//                         @"name": @"a",
//                         @"age": @30
//                     };
            
            [[testCoredataManager sharedManager] updatePersonsWithPredicate:@"name CONTAINS[c] %@"
                                                             predicateArgs:@{@"name": @"a"}
                                                             updateBlock:^(Person *person, NSMutableDictionary *data) {
                // ... 更新操作
            } completion:^(BOOL success) {
                dispatch_semaphore_signal(semaphore);
            }];
            
            dispatch_semaphore_wait(semaphore, DISPATCH_TIME_FOREVER);
            
            if (self.isUpdating) {
                [NSThread sleepForTimeInterval:20];
            }
        }
    }
}

- (void)updateTheDataInThreadA {
    while (true) {
        @autoreleasepool {
            dispatch_semaphore_t semaphore = dispatch_semaphore_create(0);
            
            [[testCoredataManager sharedManager] updatePersonsWithPredicate:@"name CONTAINS[c] %@"
                                                             predicateArgs:@{@"name": @"a"}
                                                             updateBlock:^(Person *person, NSMutableDictionary *data) {
                // ... 更新操作
            } completion:^(BOOL success) {
                dispatch_semaphore_signal(semaphore);
            }];
            
            dispatch_semaphore_wait(semaphore, DISPATCH_TIME_FOREVER);
            
            if (self.isUpdating) {
                [NSThread sleepForTimeInterval:20];
            }
        }
    }
}

@end
