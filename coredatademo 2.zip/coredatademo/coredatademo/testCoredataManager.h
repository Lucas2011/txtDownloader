//
//  testCoredataManager.h
//  coredatademo
//
//  Created by Lucas on 2/8/25.
//

#import <Foundation/Foundation.h>
#import <CoreData/CoreData.h>
#import "Person+CoreDataClass.h"
#import "Person+CoreDataProperties.h"

NS_ASSUME_NONNULL_BEGIN

@interface testCoredataManager : NSObject

@property (nonatomic, strong, readonly) NSManagedObjectContext *managedObjectContext;
@property (nonatomic, strong, readonly) NSPersistentStoreCoordinator *persistentStoreCoordinator;
@property (atomic, assign) NSUInteger operationVersion;  // 添加版本控制

// 单例
+ (instancetype)sharedManager;

// Person CRUD 操作
- (NSArray<Person *> *)fetchAllPersons;
- (BOOL)deletePerson:(Person *)person;
- (BOOL)updatePerson:(Person *)person;

- (NSArray<Person *> *)fetchAllPersonsSortedByDate:(BOOL)ascending;

// 异步版本的方法声明
- (void)fetchAllPersonsWithCompletion:(void(^)(NSArray<Person *> *persons))completion;
- (void)deletePerson:(Person *)person completion:(void(^)(BOOL success))completion;

// 条件更新方法
- (void)updatePersonsWithPredicate:(NSString *)predicateFormat
                     predicateArgs:(NSDictionary *)args
                     updateBlock:(void(^)(Person *person, NSMutableDictionary *data))updateBlock 
                     completion:(void(^)(BOOL success))completion;

// 插入方法
- (void)insertPersonWithData:(NSDictionary *)personData
                  completion:(void(^)(BOOL success))completion;

@end

NS_ASSUME_NONNULL_END
