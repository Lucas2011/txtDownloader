#import "Person+CoreDataClass.h"

@implementation Person

@end 