//
//  testCoredataManager.m
//  coredatademo
//
//  Created by Lucas on 2/8/25.
//

#import "testCoredataManager.h"
#import <CoreData/CoreData.h>

@interface testCoredataManager ()
@property (nonatomic, strong, readwrite) NSManagedObjectContext *managedObjectContext;
@property (nonatomic, strong, readwrite) NSPersistentStoreCoordinator *persistentStoreCoordinator;
@property (nonatomic, strong) NSManagedObjectModel *managedObjectModel;
@property (nonatomic, strong) dispatch_queue_t operationQueue;
@property (nonatomic, strong) dispatch_queue_t serialQueue;
@property (atomic, assign) NSUInteger updateVersion;
@property (nonatomic, strong) NSLock *updateLock;

// 添加私有方法声明
- (void)executeUpdateWithRequest:(NSFetchRequest *)request
                     inContext:(NSManagedObjectContext *)context
                   updateBlock:(void(^)(Person *person, NSMutableDictionary *data))updateBlock
                   completion:(void(^)(BOOL success))completion;
@end

@implementation testCoredataManager

#pragma mark - Singleton & Init

+ (instancetype)sharedManager {
    static testCoredataManager *sharedManager = nil;
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        sharedManager = [[self alloc] init];
    });
    return sharedManager;
}

- (instancetype)init {
    self = [super init];
    if (self) {
        [self setupCoreData];
        self.operationQueue = dispatch_queue_create("com.app.coredata.operation", DISPATCH_QUEUE_SERIAL);
        self.serialQueue = dispatch_queue_create("com.app.coredata.serial", DISPATCH_QUEUE_SERIAL);
        self.updateLock = [[NSLock alloc] init];
        self.updateVersion = 0;
    }
    return self;
}

#pragma mark - Core Data Setup

- (void)setupCoreData {
    NSURL *modelURL = [[NSBundle mainBundle] URLForResource:@"Mod" withExtension:@"momd"];
    self.managedObjectModel = [[NSManagedObjectModel alloc] initWithContentsOfURL:modelURL];
    
    self.persistentStoreCoordinator = [[NSPersistentStoreCoordinator alloc] initWithManagedObjectModel:self.managedObjectModel];
    
    NSURL *storeURL = [[self applicationDocumentsDirectory] URLByAppendingPathComponent:@"CoreDataDemo.sqlite"];
    
    NSError *error = nil;
    if (![self.persistentStoreCoordinator addPersistentStoreWithType:NSSQLiteStoreType
                                                      configuration:nil
                                                                URL:storeURL
                                                            options:nil
                                                              error:&error]) {
        NSLog(@"Core Data setup error: %@", error);
    }
    
    self.managedObjectContext = [[NSManagedObjectContext alloc] initWithConcurrencyType:NSMainQueueConcurrencyType];
    self.managedObjectContext.persistentStoreCoordinator = self.persistentStoreCoordinator;
}

#pragma mark - Utilities

- (NSURL *)applicationDocumentsDirectory {
    return [[[NSFileManager defaultManager] URLsForDirectory:NSDocumentDirectory 
                                                 inDomains:NSUserDomainMask] lastObject];
}

- (NSManagedObjectContext *)newPrivateContext {
    NSManagedObjectContext *privateContext = [[NSManagedObjectContext alloc] initWithConcurrencyType:NSPrivateQueueConcurrencyType];
    privateContext.persistentStoreCoordinator = self.persistentStoreCoordinator;
    return privateContext;
}

#pragma mark - CRUD Operations

- (NSArray<Person *> *)fetchAllPersons {
    NSManagedObjectContext *privateContext = [[NSManagedObjectContext alloc] initWithConcurrencyType:NSPrivateQueueConcurrencyType];
    privateContext.persistentStoreCoordinator = self.persistentStoreCoordinator;
    
    __block NSArray<Person *> *results = nil;
    [privateContext performBlockAndWait:^{
        @try {
            NSFetchRequest *request = [Person fetchRequest];
            request.returnsObjectsAsFaults = NO;
            
            NSError *error = nil;
            NSArray *fetchedResults = [privateContext executeFetchRequest:request error:&error];
            
            if (error) {
                NSLog(@"Fetch error: %@", error);
                results = @[];
                return;
            }
            
            // 创建不可变副本
            results = [[NSArray alloc] initWithArray:fetchedResults copyItems:NO];
            
        } @catch (NSException *exception) {
            NSLog(@"Fetch exception: %@", exception);
            results = @[];
        }
    }];
    
    return results ?: @[];
}

- (BOOL)insertPersonWithName:(NSString *)name {
    if (!name) return NO;
    
    NSManagedObjectContext *privateContext = [[NSManagedObjectContext alloc] initWithConcurrencyType:NSPrivateQueueConcurrencyType];
    privateContext.persistentStoreCoordinator = self.persistentStoreCoordinator;
    
    __block BOOL success = NO;
    [privateContext performBlockAndWait:^{
        @try {
            Person *newPerson = [[Person alloc] initWithContext:privateContext];
            newPerson.name = name;
            
            NSError *error = nil;
            success = [privateContext save:&error];
            
            if (success) {
                [self.managedObjectContext performBlockAndWait:^{
                    NSError *mainError = nil;
                    if (![self.managedObjectContext save:&mainError]) {
                        NSLog(@"Main context save error: %@", mainError);
                        success = NO;
                    }
                }];
            }
        } @catch (NSException *exception) {
            NSLog(@"Insert exception: %@", exception);
            success = NO;
        }
    }];
    
    return success;
}

- (BOOL)updatePerson:(Person *)person {
    if (!person || !person.objectID) return NO;
    
    NSManagedObjectContext *privateContext = [[NSManagedObjectContext alloc] initWithConcurrencyType:NSPrivateQueueConcurrencyType];
    privateContext.persistentStoreCoordinator = self.persistentStoreCoordinator;
    
    __block BOOL success = NO;
    [privateContext performBlockAndWait:^{
        @try {
            Person *privatePerson = (Person *)[privateContext objectWithID:person.objectID];
            if (!privatePerson) return;
            
            // 复制属性
            privatePerson.name = person.name;
            
            NSError *error = nil;
            success = [privateContext save:&error];
            
            if (success) {
                [self.managedObjectContext performBlockAndWait:^{
                    NSError *mainError = nil;
                    if (![self.managedObjectContext save:&mainError]) {
                        success = NO;
                    }
                }];
            }
        } @catch (NSException *exception) {
            NSLog(@"Update exception: %@", exception);
            success = NO;
        }
    }];
    
    return success;
}

- (BOOL)deletePerson:(Person *)person {
    if (!person || !person.objectID) return NO;
    
    NSManagedObjectContext *privateContext = [[NSManagedObjectContext alloc] initWithConcurrencyType:NSPrivateQueueConcurrencyType];
    privateContext.persistentStoreCoordinator = self.persistentStoreCoordinator;
    
    __block BOOL success = NO;
    [privateContext performBlockAndWait:^{
        @try {
            Person *privatePerson = (Person *)[privateContext objectWithID:person.objectID];
            if (!privatePerson) return;
            
            [privateContext deleteObject:privatePerson];
            
            NSError *error = nil;
            success = [privateContext save:&error];
            
            if (success) {
                [self.managedObjectContext performBlockAndWait:^{
                    NSError *mainError = nil;
                    if (![self.managedObjectContext save:&mainError]) {
                        success = NO;
                    }
                }];
            }
        } @catch (NSException *exception) {
            NSLog(@"Delete exception: %@", exception);
            success = NO;
        }
    }];
    
    return success;
}

// 获取排序后的数据
- (NSArray<Person *> *)fetchAllPersonsSortedByDate:(BOOL)ascending {
    NSManagedObjectContext *privateContext = [[NSManagedObjectContext alloc] initWithConcurrencyType:NSPrivateQueueConcurrencyType];
    privateContext.persistentStoreCoordinator = self.persistentStoreCoordinator;
    
    NSFetchRequest *request = [Person fetchRequest];
    
    // 添加排序描述符
    NSSortDescriptor *sortDescriptor = [NSSortDescriptor sortDescriptorWithKey:@"createDate" 
                                                                   ascending:ascending];
    request.sortDescriptors = @[sortDescriptor];
    
    __block NSArray<Person *> *results = nil;
    [privateContext performBlockAndWait:^{
        @try {
            NSError *error = nil;
            NSArray *fetchedResults = [privateContext executeFetchRequest:request error:&error];
            
            if (error) {
                NSLog(@"Fetch error: %@", error);
                results = @[];
                return;
            }
            
            // 创建不可变副本
            results = [[NSArray alloc] initWithArray:fetchedResults copyItems:NO];
            
        } @catch (NSException *exception) {
            NSLog(@"Fetch exception: %@", exception);
            results = @[];
        }
    }];
    
    return results ?: @[];
}

// 添加安全的获取方法
- (void)fetchAllPersonsWithCompletion:(void(^)(NSArray<Person *> *persons))completion {
    if (!completion) return;
    
    dispatch_async(self.serialQueue, ^{
        NSManagedObjectContext *privateContext = [[NSManagedObjectContext alloc] initWithConcurrencyType:NSPrivateQueueConcurrencyType];
        privateContext.persistentStoreCoordinator = self.persistentStoreCoordinator;
        
        [privateContext performBlock:^{
            NSFetchRequest *request = [Person fetchRequest];
            request.returnsObjectsAsFaults = NO;
            
            NSError *error = nil;
            NSArray *results = [privateContext executeFetchRequest:request error:&error];
            
            // 使用 objectID 传递结果
            NSArray *objectIDs = [results valueForKey:@"objectID"];
            
            dispatch_async(dispatch_get_main_queue(), ^{
                // 在主上下文中重新获取对象
                NSMutableArray *managedObjects = [NSMutableArray array];
                for (NSManagedObjectID *objectID in objectIDs) {
                    NSManagedObject *obj = [self.managedObjectContext objectWithID:objectID];
                    if (obj) {
                        [managedObjects addObject:obj];
                    }
                }
                completion(managedObjects);
            });
        }];
    });
    
}
// 异步删除Person
- (void)deletePerson:(Person *)person completion:(void(^)(BOOL success))completion {
    if (!person || !person.objectID) {
        if (completion) {
            dispatch_async(dispatch_get_main_queue(), ^{
                completion(NO);
            });
        }
        return;
    }
    
    NSManagedObjectContext *privateContext = [[NSManagedObjectContext alloc] initWithConcurrencyType:NSPrivateQueueConcurrencyType];
    privateContext.persistentStoreCoordinator = self.persistentStoreCoordinator;
    
    [privateContext performBlock:^{
        __block BOOL success = NO;
        @try {
            Person *privatePerson = (Person *)[privateContext objectWithID:person.objectID];
            if (!privatePerson) {
                if (completion) {
                    dispatch_async(dispatch_get_main_queue(), ^{
                        completion(NO);
                    });
                }
                return;
            }
            
            [privateContext deleteObject:privatePerson];
            
            NSError *error = nil;
            success = [privateContext save:&error];
            
            if (success) {
                [self.managedObjectContext performBlockAndWait:^{
                    NSError *mainError = nil;
                    if (![self.managedObjectContext save:&mainError]) {
                        success = NO;
                    }
                }];
            }
        } @catch (NSException *exception) {
            NSLog(@"Async delete exception: %@", exception);
            success = NO;
        }
        
        if (completion) {
            dispatch_async(dispatch_get_main_queue(), ^{
                completion(success);
            });
        }
    }];
}


#pragma mark - Helper Methods

// 在指定上下文中获取所有 Person 对象
- (NSArray *)fetchAllPersonsInContext:(NSManagedObjectContext *)context {
    NSFetchRequest *request = [Person fetchRequest];
    
    // 添加年龄条件
    NSPredicate *predicate = [NSPredicate predicateWithFormat:@"age < 30"];
    request.predicate = predicate;
    
    NSError *error = nil;
    NSArray *persons = [context executeFetchRequest:request error:&error];
    
    if (error) {
        NSLog(@"获取 Person 对象失败: %@", error);
        return nil;
    }
    return persons;
}

// 更新指定上下文中的 Person 对象
- (void)updatePersons:(NSArray *)persons 
           inContext:(NSManagedObjectContext *)context 
         updateBlock:(void(^)(Person *, NSMutableDictionary *))updateBlock {
    for (Person *person in persons) {
        // 在私有上下文中获取对象
        Person *privatePerson = (Person *)[context objectWithID:person.objectID];
        
        // 准备可变字典
        NSMutableDictionary *mutableData = [self mutableDataFromPerson:privatePerson];
        
        // 执行更新
        if (updateBlock) {
            updateBlock(privatePerson, mutableData);
        }
        
        // 保存更新后的数据
        privatePerson.data = [mutableData copy];
    }
}

// 从 Person 对象创建可变字典
- (NSMutableDictionary *)mutableDataFromPerson:(Person *)person {
    if ([person.data isKindOfClass:[NSDictionary class]]) {
        return [(NSDictionary *)person.data mutableCopy];
    }
    return [NSMutableDictionary dictionary];
}

// 保存上下文
- (BOOL)saveContext:(NSManagedObjectContext *)context {
    NSError *error = nil;
    BOOL success = [context save:&error];
    
    if (!success) {
        NSLog(@"保存上下文失败: %@", error);
    }
    return success;
}

// 通知主上下文并完成操作
- (void)notifyMainContextAndComplete:(void(^)(BOOL))completion {
    [self.managedObjectContext performBlock:^{
        [self.managedObjectContext reset];
        [[NSNotificationCenter defaultCenter] postNotificationName:@"DataDidUpdateNotification" 
                                                        object:nil];
        [self completeOnMainThread:completion withSuccess:YES];
    }];
}

// 在主线程执行完成回调
- (void)completeOnMainThread:(void(^)(BOOL))completion withSuccess:(BOOL)success {
    if (completion) {
        dispatch_async(dispatch_get_main_queue(), ^{
            completion(success);
        });
    }
}


- (void)updatePersonsWithPredicate:(NSString *)predicateFormat
                     predicateArgs:(NSDictionary *)args
                     updateBlock:(void(^)(Person *person, NSMutableDictionary *data))updateBlock 
                     completion:(void(^)(BOOL success))completion {
    dispatch_async(self.serialQueue, ^{
        NSManagedObjectContext *privateContext = [self newPrivateContext];
        
        [privateContext performBlock:^{
            @try {
                // 创建带条件的请求
                NSFetchRequest *request = [Person fetchRequest];
                
                // 构建谓词
                NSPredicate *predicate = [NSPredicate predicateWithFormat:predicateFormat 
                                                     argumentArray:@[args]];
                request.predicate = predicate;
                
                // 执行查询和更新
                [self executeUpdateWithRequest:request
                                  inContext:privateContext
                                updateBlock:updateBlock
                                completion:completion];
                
            } @catch (NSException *exception) {
                NSLog(@"批量更新失败: %@", exception);
                [self completeOnMainThread:completion withSuccess:NO];
            }
        }];
    });
}

// 安全地插入 Person 对象
- (void)insertPersonWithData:(NSDictionary *)personData 
                 completion:(void(^)(BOOL success))completion {
    
    dispatch_async(self.serialQueue, ^{
        // 创建私有上下文
        NSManagedObjectContext *privateContext = [self newPrivateContext];
        
        [privateContext performBlock:^{
            @try {
                // 在私有上下文中创建新的 Person
                Person *newPerson = [[Person alloc] initWithContext:privateContext];
                
                // 设置属性
                newPerson.name = personData[@"name"];
                newPerson.age = [personData[@"age"] integerValue];
                
                // 设置字典数据
                if (personData[@"data"] && [personData[@"data"] isKindOfClass:[NSDictionary class]]) {
                    newPerson.data = [personData[@"data"] copy];
                }
                
                // 设置创建时间
                
                // 保存上下文
                if ([self saveContext:privateContext]) {
                    // 通知主上下文刷新
                    [self notifyMainContextAndComplete:completion];
                } else {
                    [self completeOnMainThread:completion withSuccess:NO];
                }
                
            } @catch (NSException *exception) {
                NSLog(@"插入失败: %@", exception);
                [self completeOnMainThread:completion withSuccess:NO];
            }
        }];
    });
}

// 添加方法实现
- (void)executeUpdateWithRequest:(NSFetchRequest *)request
                     inContext:(NSManagedObjectContext *)context
                   updateBlock:(void(^)(Person *person, NSMutableDictionary *data))updateBlock
                   completion:(void(^)(BOOL success))completion {
    
    NSError *error = nil;
    NSArray *persons = [context executeFetchRequest:request error:&error];
    
    if (error) {
        NSLog(@"获取数据失败: %@", error);
        [self completeOnMainThread:completion withSuccess:NO];
        return;
    }
    
    for (Person *person in persons) {
        NSMutableDictionary *mutableData = [person.data mutableCopy];
        if (!mutableData) {
            mutableData = [NSMutableDictionary dictionary];
        }
        
        updateBlock(person, mutableData);
        person.data = [mutableData copy];
    }
    
    // 保存更改
    if ([self saveContext:context]) {
        [self notifyMainContextAndComplete:completion];
    } else {
        [self completeOnMainThread:completion withSuccess:NO];
    }
}

@end
